#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QMessageBox>
#include<QStringList>
#include<QComboBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    db=QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/Users/User/OneDrive/Desktop/Durutto included all/Durutto-final/duruttodatabase.db");
    db.open();
    //QSqlDatabase db = QSqlDatabase::database(); // Assuming you have an open database connection
    if (db.isOpen()) {
        qDebug() << "Database is connected.";
    } else {
        qDebug() << "Database is not connected.";
    }
   // qDebug()
    connect(ui->pushButton_87, &QPushButton::clicked, this, &MainWindow::checkPrinter);
    //
    currentTimeS = QDateTime::currentSecsSinceEpoch();
    qDebug()<<"currentTimeS "<<currentTimeS;
    //
   // QSqlQuery q3,query;
    cl1 = "rgb(6, 156, 140 )";  //defaultcolor
    cl2 = "rgb(128, 0, 32 )";  //red
    cl3 = "rgb(34, 139, 34)";   //green
    clw = "rgb(255,255,255)";   //white
    ft = "700 12pt 'Poppins'";
    ft1 = "700 9pt 'Poppins'";
    defaultColor = "background-color: " + cl1 + "; color: rgb(255, 255, 255); font: " + ft + ";";
    redColor = "background-color: " + cl2 + "; color: rgb(255, 255, 255); font: " + ft + ";";
    greenColor = "background-color: " + cl3 + "; color: rgb(255, 255, 255); font: " + ft + ";";
    qsFont= "background-color: " + clw + "; color: rgb(0, 0, 0); font: " + ft1 + ";";
    //ui->text_label->setStyleSheet(styleSheet);


    ////
    QStringList list;
    list <<"Ctg" <<"hss"<<"Dhaka"<<"sds";
    ui->from_box->addItems(list);
    ui->to_box->addItems(list);
     //// end of mainwindow parent
     ///

}

MainWindow::~MainWindow()
{
    delete ui;
    db.close();
}

void MainWindow::checkPrinter() {

    QWidget *currentPage = ui->stackedWidget->findChild<QWidget*>("invoice");

    if (currentPage) {
        qDebug() << "Found the current page! Capturing a screenshot...";
        QPixmap screenshot(currentPage->size());

        // Render the specified page into the QPixmap
        currentPage->render(&screenshot);

        if (!screenshot.isNull()) {
            qDebug() << "Screenshot captured successfully!";

            // Save the screenshot as a PDF with higher DPI
            QPrinter printer(QPrinter::HighResolution);
            printer.setOutputFormat(QPrinter::PdfFormat);

            // Set the page size to the exact size of the captured screenshot
            printer.setPageSize(QPageSize(screenshot.size(), QPageSize::Millimeter));

            // Set a higher DPI for better quality (e.g., 300)
            printer.setResolution(300);

            QString filePath = QFileDialog::getSaveFileName(this, "Save PDF File", QString(), "PDF Files (*.pdf)");

            if (!filePath.isEmpty()) {
                printer.setOutputFileName(filePath);
                QPainter painter(&printer);

                // Get the dimensions of the PDF page
                int pageWidth = printer.width();
                int pageHeight = printer.height();

                // Calculate the scaling factor to fit the page
                qreal scaleFactorX = static_cast<qreal>(pageWidth) / screenshot.width();
                qreal scaleFactorY = static_cast<qreal>(pageHeight) / screenshot.height();
                qreal scaleFactor = qMin(scaleFactorX, scaleFactorY);

                // Scale and draw the screenshot to fit the page
                painter.scale(scaleFactor, scaleFactor);
                painter.drawPixmap(0, 0, screenshot);

                painter.end();

                qDebug() << "PDF saved successfully to: " << filePath;
            } else {
                qDebug() << "PDF saving canceled.";
            }
        } else {
            qDebug() << "Screenshot capture failed.";
        }
    } else {
        qDebug() << "The specified page 'myPage' was not found.";
    }
}

void MainWindow::configureSeatButton(const QString &seatName, QPushButton *button, QString &var) {
    QSqlQuery query;

    if (query.prepare("SELECT Status FROM sit WHERE sitname = :seatName")) {
        query.bindValue(":seatName", seatName);

        if (query.exec() && query.next()) {
            QString seatStatus = query.value(0).toString();
            qDebug() << "Seat " << seatName << " has status: " << seatStatus;

            if (seatStatus == "booked") {
                button->setCheckable(false);
                button->setStyleSheet(redColor);
                button->setDisabled(true);
                var = "B"; // Update the flag variable
            } else {
                button->setStyleSheet(defaultColor);
                button->setCheckable(true);
                var = "N"; // Update the flag variable
            }
        } else {
            qDebug() << "Seat " << seatName << " not found or an error occurred: " << query.lastError();
        }
    }
}
/*
        // seat B2 started
        qDebug()<<"value"<<B2;
    if (B2 == "1")
    {   //B2 cheacked
         TotalString+="B2";
         ui->pushButton_29->setStyleSheet(redColor);
         if (qPB2.prepare("UPDATE sit SET Status = :status4 WHERE sitname = :sitname4"))
         {
         qPB2.bindValue(":status4", "booked"); qPB2.bindValue(":sitname4", "B2");
         if (!qPB2.exec()) { qDebug() << "Error executing query: " << qPB2.lastError();}
         else { qDebug() << "Update successful1234";}
         }
         else { qDebug() << "Error preparing query: " << qPB2.lastError(); }
    }
    else if (B2 == "0")   //B2 unchecked
    {
        ui->pushButton_29->setStyleSheet(defaultColor);
        if (qPB2.prepare("UPDATE sit SET Status = :status4 WHERE sitname = :sitname4"))
        {
          qPB2.bindValue(":status4", "not_booked");
          qPB2.bindValue(":sitname4", "B2");
        if (!qPB2.exec()) {  qDebug() << "Error executing query: " <<qPB2.lastError();}
        else { qDebug() << "Update successful"; }
        }
    }
        ///end of B2
*/
void MainWindow::refundSeat(const QString &seatName, QPushButton *button, QSqlQuery &query) {
    if (query.prepare("UPDATE sit SET Status = :status WHERE sitname = :sitname")) {
        query.bindValue(":status", "not_booked");
        query.bindValue(":sitname", seatName);
        if (!query.exec()) {
            qDebug() << "Error executing query for seat " << seatName << ": " << query.lastError();
        } else {
            qDebug() << "Update successful for seat " << seatName;
            // Update the button only if the query execution is successful
            if (button) {
                button->setChecked(false);
                button->setStyleSheet(defaultColor);
            }
        }
    }
}
void MainWindow::updateStatus(const QString &seatName, QPushButton *button, QString &flag) {
    QSqlDatabase db = QSqlDatabase::database();  // Get the existing database connection

    db.transaction();  // Start a database transaction

    QSqlQuery query(db);

    QString status;

    if (flag == "1") {
        status = "booked";
        TotalString += seatName;
        button->setStyleSheet(redColor);
    } else if (flag == "0") {
        status = "not_booked";
        button->setStyleSheet(defaultColor);
    } else {
        db.rollback();  // Roll back the transaction if flag is not "1" or "0
        query.finish();  // Free resources associated with the query
        return;
    }

    if (query.prepare("UPDATE sit SET Status = :status1 WHERE sitname = :seatname1")) {
        query.bindValue(":status1", status);
        query.bindValue(":seatname1", seatName);

        if (query.exec()) {
            db.commit();  // Commit the transaction if the query executed successfully
            query.finish();  // Free resources associated with the query
            qDebug() << "Seat " << seatName << " status updated to " << status;
        } else {
            db.rollback();  // Roll back the transaction if the query execution failed
            query.finish();  // Free resources associated with the query
            qDebug() << "Error executing query: " << query.lastError();
        }
    } else {
        db.rollback();  // Roll back the transaction if the query preparation failed
        query.finish();  // Free resources associated with the query
        qDebug() << "Error preparing query: " << query.lastError();
    }
}









void MainWindow::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}


void MainWindow::on_pushButton_13_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}


void MainWindow::on_pushButton_10_clicked()   ////Login
{
    email=ui->lineEdit_7->text();
    password=ui->lineEdit_8->text();
    QSqlQuery qlog;
    qlog.exec("SELECT * FROM user WHERE Email ='"+email+"'AND Password = '"+password+"' ");
    if(qlog.next()&&email!=""){
    // Acessing user's data
    ///
    QSqlQuery qinv;
    qinv.prepare("SELECT Name, Contact,Time FROM user WHERE Email = :qemail");
    qinv.bindValue(":qemail", email);
    if (qinv.exec() && qinv.next()) {
        username = qinv.value(0).toString();
        contact = qinv.value(1).toString();
        time = qinv.value(2).toString();
        qDebug() << "Name: " << username;
        qDebug() << "Contact: " << contact;
        qDebug() << "time: " << time;
    }
    // Booked Seats
    EmailX=username;
    QSqlQuery qFS;
    qFS.prepare("SELECT seatString FROM user WHERE Email = :qemail");
    qFS.bindValue(":qemail", email);
    if (qFS.exec() && qFS.next()) {
        seatValue = qFS.value(0).toString();
        qDebug() << "SeatString for " << seatValue << ": " << email;
    }
    QString seatString = seatValue;
    qDebug() << seatValue;
    QStringList seatStringList;
    std::vector<std::string> seatsVector;
    for (int i = 0; i < seatString.length(); i += 2)
    {
        QString seat = seatString.mid(i, 2); // Extract a 2-character seat
        seatsVector.push_back(seat.toStdString());
        seatStringList << seat;
    }
    QString refundSS;
    qDebug()<<"refundss2"<<refundSS;
    qDebug()<<"seatstring"<<seatStringList;

    int vectorSize = seatsVector.size();
    if(seatsVector[0]=="00"){
        refundSS= " ";
        qDebug()<<"refundss"<<refundSS;
    }
    else{
    refundSS=seatStringList.join(",");
    qDebug()<<seatsVector[0];qDebug()<<vectorSize;
    qDebug()<<refundSS;
    }
    //Booked Seats end

    // Sending information to dashboard
    ///
    //name
    ui->label_62->setText(username);
    ui->label_62->setStyleSheet(qsFont);
    //contact
    ui->label_106->setText(contact);
    ui->label_106->setStyleSheet(qsFont);
    //Email
    ui->label_85->setText(email);
    ui->label_85->setStyleSheet(qsFont);
    // Seats
    ui->label_105->setText(refundSS);
    ui->label_105->setStyleSheet(qsFont);
    ///



    ///



    ///
    ui->stackedWidget->setCurrentIndex(14);
    }
    else {
    QMessageBox::warning(this,tr("warning!"),tr("wrong password!"));
    }
    ui->lineEdit_7->clear();
    ui->lineEdit_8->clear();
}


void MainWindow::on_pushButton_14_clicked()
{
    Date1=ui->dateEdit->text();
    qDebug()<<"date "<<Date1;
    if(fromS==toS){
    QMessageBox::warning(this,tr("warning!"),tr("Location & destination cannot be same"));

    }
    else{
    ui->label_334->setText(fromS);
    ui->label_335->setText(toS);
    ui->label_336->setText(fromS);
    ui->label_337->setText(toS);
    ui->stackedWidget->setCurrentIndex(7);
    ui->Time1->setText(Date1);
    }

}


void MainWindow::on_pushButton_7_clicked()   //signup Button
{
    sname=ui->lineEdit->text();
    semail=ui->lineEdit_2->text();
    snum=ui->lineEdit_3->text();
    spass=ui->lineEdit_4->text();
    QString tt="02/11/23";
    QString st="00";
    QSqlQuery q2;
    q2.exec("INSERT INTO USER(Name,Email,Contact,Password,Time,seatString) VALUES('"+sname+"','"+semail+"','"+snum+"','"+spass+"','"+tt+"','"+st+"')");
    ui->stackedWidget->setCurrentIndex(5);
    //QSqlQuery q2;
    //q2.exec("INSERT INTO USER(Name,Email,Contact,Password) VALUES('"+sname+"','"+semail+"','"+snum+"','"+spass+"')");
    //ui->stackedWidget->setCurrentIndex(4);
    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
    ui->lineEdit_3->clear();
    ui->lineEdit_4->clear();

}


void MainWindow::on_pushButton_21_clicked() { //Payment Submit Button

    QString trx=ui->lineEdit_11->text();
    QSqlQuery qtrxid;
    qtrxid.exec("SELECT * FROM TRXID WHERE Trxid ='"+trx+"'");
    if(qtrxid.next()&&trx!=""){

    //invoice count started
    counter1=0;
   // bookedSeatCount
    if(A1=="1")counter1++;if(A2=="1")counter1++;if(A3=="1")counter1++;
    if(B1=="1")counter1++;if(B2=="1")counter1++;if(B3=="1")counter1++;
    if(C1=="1")counter1++;if(C2=="1")counter1++;if(C3=="1")counter1++;
    if(D1=="1")counter1++;if(D2=="1")counter1++;if(D3=="1")counter1++;
    if(E1=="1")counter1++;if(E2=="1")counter1++;if(E3=="1")counter1++;
    if(F1=="1")counter1++;if(F2=="1")counter1++;if(F3=="1")counter1++;
    int currentCount=counter1;
    qDebug() << "currentCount: " << currentCount;
    int payment = 0;
    qDebug() << "total payment: " << payment;
    for (int i = 0; i < currentCount; i++) {
    payment += 2100;
    qDebug() << "total payment:  " << i <<" "<<payment;
    }
    qDebug() << "final total payment: " << payment;

    //invoice counter end
    //invoice started

        //username
        ui->label_13->setText(username);
        ui->label_13->setStyleSheet("background-color :rgb(255,255,255);color :rgb(0,0,0);");
        //contact
        ui->lb_inv_contact->setText(contact);
        ui->lb_inv_contact->setStyleSheet("background-color :rgb(255,255,255);color :rgb(0,0,0);");
        //Email
        ui->lb_inv_Email->setText(email);
        ui->lb_inv_Email->setStyleSheet("background-color :rgb(255,255,255);color :rgb(0,0,0);");
        // Time
        ui->lb_inv_Date->setText(Date1);
        ui->lb_inv_Date->setStyleSheet("background-color :rgb(255,255,255);color :rgb(0,0,0);");
        //currentcounter
        ui->lb_inv_Seats->setText(QString::number(currentCount));
        ui->lb_inv_Seats->setStyleSheet("background-color :rgb(255,255,255);color :rgb(0,0,0);");
        //payment
        ui->lb_inv_Paid->setText(QString::number(payment));
        ui->lb_inv_Paid->setStyleSheet("background-color :rgb(255,255,255);color :rgb(0,0,0);");

    ///end invoice

    ///Current Final SeatString

        /*
        if (A1 == "1")
        {   //A1 cheacked
    TotalString+="A1";
    ui->pushButton_4->setStyleSheet(redColor);

    if (qPA1.prepare("UPDATE sit SET Status = :status WHERE sitname = :sitname1"))
    {
    qPA1.bindValue(":status", "booked"); qPA1.bindValue(":sitname", "A1");
    if (!qPA1.exec()) { qDebug() << "Error executing query: " << qPA1.lastError();}
    else { qDebug() << "Update successful1234";}
    }
    else { qDebug() << "Error preparing query: " << qPA1.lastError(); }
        }
        else if (A1 == "0")
        {
    ui->pushButton_4->setStyleSheet(defaultColor);
    if (qPA1.prepare("UPDATE sit SET Status = :status WHERE sitname = :sitname"))
    {
    qPA1.bindValue(":status", "not_booked");
    qPA1.bindValue(":sitname", "A1");
    if (!qPA1.exec()) {  qDebug() << "Error executing query: " << qPA1.lastError();}
    else { qDebug() << "Update successful"; }
    }
        }
        ///end of A1
        */

        // seat B2 started
        /*
  QSqlQuery qPB2,qPA2;
        qDebug()<<"value"<<B2;
    if (B2 == "1")
    {   //B2 cheacked
         TotalString+="B2";
         ui->pushButton_29->setStyleSheet(redColor);
         if (qPB2.prepare("UPDATE sit SET Status = :status4 WHERE sitname = :sitname4"))
         {
         qPB2.bindValue(":status4", "booked"); qPB2.bindValue(":sitname4", "B2");
         if (!qPB2.exec()) { qDebug() << "Error executing query: " << qPB2.lastError();}
         else { qDebug() << "Update successful1234";}
         }
         else { qDebug() << "Error preparing query: " << qPB2.lastError(); }
    }
    else if (B2 == "0")   //B2 unchecked
    {
        ui->pushButton_29->setStyleSheet(defaultColor);
        if (qPB2.prepare("UPDATE sit SET Status = :status4 WHERE sitname = :sitname4"))
        {
          qPB2.bindValue(":status4", "not_booked");
          qPB2.bindValue(":sitname4", "B2");
        if (!qPB2.exec()) {  qDebug() << "Error executing query: " <<qPB2.lastError();}
        else { qDebug() << "Update successful"; }
        }
    }
        ///end of B2

    // seat A2 started
    qDebug() << "value" << A2;
    if (A2 == "1")
    {   // A2 checked
        TotalString += "A2";
        ui->pushButton_5->setStyleSheet(redColor);  // Modify to use pushButton_5 for A2
        if (qPA2.prepare("UPDATE sit SET Status = :statusA2 WHERE sitname = :sitnameA2"))  // Replace with the appropriate query variable qPA2
        {
        qPA2.bindValue(":statusA2", "booked"); qPA2.bindValue(":sitnameA2", "A2");  // Replace with the appropriate bind values
        if (!qPA2.exec()) { qDebug() << "Error executing query: " << qPA2.lastError(); }
        else { qDebug() << "Update successful"; }
        }
        else { qDebug() << "Error preparing query: " << qPA2.lastError(); }
    }
    else if (A2 == "0")   // A2 unchecked
    {
        ui->pushButton_5->setStyleSheet(defaultColor);  // Modify to use pushButton_5 for A2
        if (qPA2.prepare("UPDATE sit SET Status = :statusA2 WHERE sitname = :sitnameA2"))  // Replace with the appropriate query variable qPA2
        {
        qPA2.bindValue(":statusA2", "not_booked");
        qPA2.bindValue(":sitnameA2", "A2");  // Replace with the appropriate bind values
        if (!qPA2.exec()) {  qDebug() << "Error executing query: " <<qPA2.lastError(); }
        else { qDebug() << "Update successful"; }
        }
        ///end of A2
    }
*/


     updateStatus("A1", ui->pushButton_4, A1);
     updateStatus("A2", ui->pushButton_5, A2);
     qDebug()<<"Last Update status"<<A1;

     updateStatus("A3", ui->pushButton_27, A3);
     updateStatus("B1", ui->pushButton_30, B1);
     updateStatus("B2", ui->pushButton_29, B2);
     updateStatus("B3", ui->pushButton_28, B3);
     updateStatus("C1", ui->pushButton_32, C1);

     updateStatus("C2", ui->pushButton_31, C2);
     updateStatus("C3", ui->pushButton_33, C3);
     updateStatus("D1", ui->pushButton_41, D1);
     updateStatus("D2", ui->pushButton_40, D2);
     updateStatus("D3", ui->pushButton_42, D3);


     updateStatus("E1", ui->pushButton_35, E1);
     updateStatus("E2", ui->pushButton_34, E2);
     updateStatus("E3", ui->pushButton_36, E3);
     updateStatus("F1", ui->pushButton_38, F1);
     updateStatus("F2", ui->pushButton_37, F2);
     updateStatus("F3", ui->pushButton_39, F3);




      //Ended
    qDebug()<<TotalString;
//Newly Booked Seats
    QString CurrentString=TotalString.join("");
     qDebug()<<CurrentString;

     // Extract list
     QSqlQuery qFS;
     qFS.prepare("SELECT seatString FROM user WHERE Email = :qemail");
     qFS.bindValue(":qemail", email);
     if (qFS.exec() && qFS.next()) {
        seatValue = qFS.value(0).toString();
        qDebug() << "SeatString for " << seatValue << ": " << email;
     }
     QString seatString = seatValue;
     qDebug() << seatValue;
     QStringList seatStringList;
     std::vector<std::string> seatsVector;
     for (int i = 0; i < seatString.length(); i += 2)
     {
        QString seat = seatString.mid(i, 2);
        seatsVector.push_back(seat.toStdString());
    //Extracted Current seats
        seatStringList << seat;
     }
     int vectorSize = seatsVector.size();
     QString refundSS=seatStringList.join(",");
//Existing seats!
     qDebug()<<"afgsjsdjd"<<seatStringList;

       QString newstr=seatStringList.join("");
     qDebug()<<seatsVector[0];qDebug()<<vectorSize;
     qDebug()<<refundSS;
     qDebug()<<"Extracted:"<<newstr;
     qDebug()<<"Current:"<<CurrentString;
     // Extracting done

     //Update list
     QSqlQuery qCseat;
     qDebug()<<"Current STTR:"<<CurrentString;
     if(newstr=="00"){CurrentString=CurrentString;}
     else
     {CurrentString=newstr+CurrentString;}
     qCseat.prepare("UPDATE user SET seatString = :newString WHERE Email = :qemail");
     qCseat.bindValue(":newString",CurrentString );
     qCseat.bindValue(":qemail",email);
     qDebug()<<email;
     if (!qCseat.exec()) {qDebug() << "Error executing query string: " << qCseat.lastError(); }
     else {qDebug() << "Update successful total string";}
     //Updating finished

     ui->label_105->setText(refundSS);
     ui->label_105->setStyleSheet(qsFont);
     //Booked Seats end

      TotalString.clear();
    ui->stackedWidget->setCurrentIndex(8);
     ui->lineEdit_12->clear();
     ui->lineEdit_11->clear();
    }
    else{
     QMessageBox::warning(this,tr("warning!"),tr("Not matched"));
     ui->lineEdit_11->clear();
    }
}

void MainWindow::on_pushButton_24_clicked()
{
    ui->stackedWidget->setCurrentIndex(6);

}


void MainWindow::on_pushButton_4_toggled(bool checked) { //A1 button
    //A1 Button
    if(A1=="B"){ return;}
    if (checked) {
        qDebug() << "OK";
        A1 = "1";
        ui->pushButton_4->setStyleSheet(greenColor);
    } else {
        qDebug() << "NOT OK";
        A1 = "0";
        ui->pushButton_4->setStyleSheet(defaultColor);
    }
}

void MainWindow::on_pushButton_5_toggled(bool checked) { //A2 Btn
    if(A2=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    A2 = "1";
    ui->pushButton_5->setStyleSheet(greenColor);
    } else {
    A2 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_5->setStyleSheet(defaultColor);
    }


}


void MainWindow::on_pushButton_27_toggled(bool checked){ //A3 Btn
    if(A3=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    A3 = "1";
    ui->pushButton_27->setStyleSheet(greenColor);
    } else {
    A3 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_27->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_30_toggled(bool checked){ //B1 Btn
    if(B1=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    B1 = "1";
    ui->pushButton_30->setStyleSheet(greenColor);
    } else {
    B1 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_30->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_29_toggled(bool checked){ //B2 Btn
    if(B2=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    B2 = "1";
    ui->pushButton_29->setStyleSheet(greenColor);
    } else {
    B2 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_29->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_28_toggled(bool checked){ //B3 Btn
    if(B3=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    B3 = "1";
    ui->pushButton_28->setStyleSheet(greenColor);
    } else {
    B3 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_28->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_32_toggled(bool checked){ //C1 Btn
    if(C1=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    C1 = "1";
    ui->pushButton_32->setStyleSheet(greenColor);
    } else {
    C1 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_32->setStyleSheet(defaultColor);
    }
}
void MainWindow::on_pushButton_31_toggled(bool checked) //C2 button
{
    if(C2=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    C2 = "1";
    ui->pushButton_31->setStyleSheet(greenColor);
    } else {
    C2 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_31->setStyleSheet(defaultColor);
    }
}
void MainWindow::on_pushButton_33_toggled(bool checked) //C3 button
{
    if(C3=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    C3 = "1";
    ui->pushButton_33->setStyleSheet(greenColor);
    } else {
    C3 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_33->setStyleSheet(defaultColor);
    }
}
void MainWindow::on_pushButton_41_toggled(bool checked)
{
    if(D1=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    D1 = "1";
    ui->pushButton_41->setStyleSheet(greenColor);
    } else {
    D1 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_41->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_40_toggled(bool checked) //D2 btn
{
    if(D2=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    D2 = "1";
    ui->pushButton_40->setStyleSheet(greenColor);
    } else {
    D2 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_40->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_42_toggled(bool checked) //D3 btn
{
    if(D3=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    D3 = "1";
    ui->pushButton_42->setStyleSheet(greenColor);
    } else {
    D3 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_42->setStyleSheet(defaultColor);
    }
}
void MainWindow::on_pushButton_35_toggled(bool checked) //E1
{
    if(E1=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    E1 = "1";
    ui->pushButton_35->setStyleSheet(greenColor);
    } else {
    E1 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_35->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_34_toggled(bool checked) //E2
{
    if(E2=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    E2 = "1";
    ui->pushButton_34->setStyleSheet(greenColor);
    } else {
    E2 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_34->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_36_toggled(bool checked)  //E3 BUTTON
{
    if(E3=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    E3 = "1";
    ui->pushButton_36->setStyleSheet(greenColor);
    } else {
    E3 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_36->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_38_toggled(bool checked) //F1 BUUTON
{
    if(F1=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    F1 = "1";
    ui->pushButton_38->setStyleSheet(greenColor);
    } else {
    F1 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_38->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_37_toggled(bool checked) //F2 BUTTON
{
    if(F2=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    F2 = "1";
    ui->pushButton_37->setStyleSheet(greenColor);
    } else {
    F2 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_37->setStyleSheet(defaultColor);
    }
}


void MainWindow::on_pushButton_39_toggled(bool checked)  //F3 BUTTON
{
    if(F3=="B"){return;}
    if (checked) {
    qDebug() << "OK";
    F3 = "1";
    ui->pushButton_39->setStyleSheet(greenColor);
    } else {
    F3 = "0";
    qDebug() << "NOT OK";
    ui->pushButton_39->setStyleSheet(defaultColor);
    }
}





void MainWindow::on_pushButton_86_clicked()
{
   ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_9_clicked()
{
   ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_12_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_18_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_23_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->lineEdit_12->clear();
    ui->lineEdit_11->clear();
}


void MainWindow::on_pushButton_20_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}


void MainWindow::on_pushButton_26_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_16_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_11_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}


void MainWindow::on_pushButton_19_clicked()
{
    ui->stackedWidget->setCurrentIndex(14);

}


void MainWindow::on_pushButton_25_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}


void MainWindow::on_pushButton_22_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
    ui->lineEdit_12->clear();
    ui->lineEdit_11->clear();
}


void MainWindow::on_pushButton_85_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}


void MainWindow::on_pushButton_17_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_15_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(13);
}


void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void MainWindow::on_pushButton_87_clicked()
{

}


void MainWindow::on_pushButton_62_clicked()//Book my Ticket
{

    configureSeatButton("A1", ui->pushButton_4, A1);
    configureSeatButton("A2", ui->pushButton_5, A2);
qDebug()<<"Initial Book seatStatus"<<A2;
    configureSeatButton("A3", ui->pushButton_27, A3);
    configureSeatButton("B1", ui->pushButton_30, B1);
    configureSeatButton("B2", ui->pushButton_29, B2);
    configureSeatButton("B3", ui->pushButton_28, B3);
    qDebug()<<"Initial Book seatStatus B1"<<B1;
    configureSeatButton("C1", ui->pushButton_32, C1);
    configureSeatButton("C2", ui->pushButton_31, C2);
    configureSeatButton("C3", ui->pushButton_33, C3);
    configureSeatButton("D1", ui->pushButton_41, D1);
    configureSeatButton("D2", ui->pushButton_40, D2);
    configureSeatButton("D3", ui->pushButton_42, D3);

    configureSeatButton("E1", ui->pushButton_35, E1);
    configureSeatButton("E2", ui->pushButton_34, E2);
    configureSeatButton("E3", ui->pushButton_36, E3);
    configureSeatButton("F1", ui->pushButton_38, F1);
    configureSeatButton("F2", ui->pushButton_37, F2);
    configureSeatButton("F3", ui->pushButton_39, F3);

    ui->stackedWidget->setCurrentIndex(3);
}


void MainWindow::on_pushButton_61_clicked()
{
     ui->stackedWidget->setCurrentIndex(9);
}


void MainWindow::on_pushButton_43_clicked() // Refund Submit Button
{
     //
     QString applyD = ui->lineEdit_14->text();
     QString Xa= applyD.mid(0,2);
     QString Xb= applyD.mid(3,2);
     QString Xc= applyD.mid(6,4);
     qDebug()<<"month string"<<Xb;
     qint64 dayD = std::stoi(Xa.toStdString());
     qint64 monthD = std::stoi(Xb.toStdString());
     qint64 yearD = std::stoi(Xc.toStdString());
     qDebug()<<" Day:"<<dayD;
     qDebug()<<" Month:"<<monthD;
     qDebug()<<" Yaer:"<<yearD;

     QDate givenDate(yearD, monthD, dayD);
     QTime time(0, 0, 0);
     QDateTime dateTime(givenDate, time, Qt::UTC);
     qint64 secondsSinceEpoch = dateTime.toSecsSinceEpoch();
     qDebug() << "Seconds since epoch:" << secondsSinceEpoch;
     qint64 dayA_secs = currentTimeS ;
     qint64 dayB_secs =  secondsSinceEpoch ;
     qint64 timeDifference = std::abs(dayA_secs - dayB_secs);
     // Number of seconds in 24 hours
     qint64 secondsIn24Hours = 24 * 60 * 60; // 24 hours * 60 mins * 60 secs

     if (timeDifference <= secondsIn24Hours) {
    qDebug() << "The difference between day A and day B is less than or equal to 24 hours.";
     //
     // Extract list
     QSqlQuery qFS;
     qFS.prepare("SELECT seatString FROM user WHERE Email = :qemail");
     qFS.bindValue(":qemail", email);
     if (qFS.exec() && qFS.next()) {
    seatValue = qFS.value(0).toString();
    qDebug() << "SeatString for " << seatValue << ": " << email;
     }
     QString seatString = seatValue;
     qDebug() << " REFUNDNAME "<<email;
     qDebug() << " REFUNDEMAIL "<<EmailX;


     //
     QSqlQuery qF;
     qF.exec("INSERT INTO Refundlist(NAME,EMAIL,SEAT) VALUES('"+EmailX+"','"+email+"','"+seatString+"')");
     //
     qDebug() << seatValue;
     QSqlQuery qPA1,qPA2,qPA3,qPB1,qPB2,qPB3,qPC1,qPC2,qPC3,qPD1,qPD2,qPD3,qPE1,qPE2,qPE3,qPF1,qPF2,qPF3;

     for (int i = 0; i < seatString.length(); i += 2)
     {
        QString seat = seatString.mid(i, 2);

        if(seat=="A1")refundSeat("A1", ui->pushButton_4, qPA1);
        if(seat=="A2")refundSeat("A2", ui->pushButton_5, qPA2);
        if(seat=="A3")refundSeat("A3", ui->pushButton_27, qPA3);
        if(seat=="B1")refundSeat("B1", ui->pushButton_30, qPB1);
        if(seat=="B2")refundSeat("B2", ui->pushButton_29, qPB2);
        if(seat=="B3")refundSeat("B3", ui->pushButton_28, qPB3);
        if(seat=="C1")refundSeat("C1", ui->pushButton_32, qPC1);
        if(seat=="C2")refundSeat("C2", ui->pushButton_31, qPC2);
        if(seat=="C3")refundSeat("C3", ui->pushButton_33, qPC3);
        if(seat=="D1")refundSeat("D1", ui->pushButton_41, qPD1);
        if(seat=="D2")refundSeat("D2", ui->pushButton_40, qPD2);
        if(seat=="D3")refundSeat("D3", ui->pushButton_42, qPD3);
        if(seat=="E1")refundSeat("E1", ui->pushButton_35, qPE1);
        if(seat=="E2")refundSeat("E2", ui->pushButton_34, qPE2);
        if(seat=="E3")refundSeat("E3", ui->pushButton_36, qPE3);
        if(seat=="F1")refundSeat("F1", ui->pushButton_38, qPF1);
        if(seat=="F2")refundSeat("F2", ui->pushButton_37, qPF2);
        if(seat=="F3")refundSeat("F3", ui->pushButton_39, qPF3);

/*
    refundSeat("A1", ui->pushButton_4, qPA1);
    refundSeat("A2", ui->pushButton_5, qPA2);
    refundSeat("A3", ui->pushButton_27, qPA3);
    refundSeat("B1", ui->pushButton_30, qPB1);
    refundSeat("B2", ui->pushButton_29, qPB2);
    refundSeat("B3", ui->pushButton_28, qPB3);
    refundSeat("C1", ui->pushButton_32, qPC1);
    refundSeat("C2", ui->pushButton_31, qPC2);
    refundSeat("C3", ui->pushButton_33, qPC3);
    refundSeat("D1", ui->pushButton_41, qPD1);
    refundSeat("D2", ui->pushButton_40, qPD2);
    refundSeat("D3", ui->pushButton_42, qPD3);
    refundSeat("E1", ui->pushButton_35, qPE1);
    refundSeat("E2", ui->pushButton_34, qPE2);
    refundSeat("E3", ui->pushButton_36, qPE3);
    refundSeat("F1", ui->pushButton_38, qPF1);
    refundSeat("F2", ui->pushButton_37, qPF2);
    refundSeat("F3", ui->pushButton_39, qPF3);
*/

         // seat A1 started
        /*
        if (seat == "A1")
        {
           ui->pushButton_4->setChecked(false);
           ui->pushButton_4->setStyleSheet(defaultColor);
           if (qPA1.prepare("UPDATE sit SET Status = :status WHERE sitname = :sitname"))
           {
              qPA1.bindValue(":status", "not_booked");
              qPA1.bindValue(":sitname", "A1");
              if (!qPA1.exec()) {  qDebug() << "Error executing query: " << qPA1.lastError();}
              else { qDebug() << "Update successful"; }
           }
        }
        //end of A1
        // seat A2 started
        if (seat == "A2")
        {
           ui->pushButton_5->setChecked(false);

           ui->pushButton_5->setStyleSheet(defaultColor);
           if (qPA2.prepare("UPDATE sit SET Status = :status WHERE sitname = :sitname"))
           {
              qPA2.bindValue(":status", "not_booked");
              qPA2.bindValue(":sitname", "A2");
              if (!qPA2.exec()) {  qDebug() << "Error executing query: " << qPA2.lastError();}
              else { qDebug() << "Update successful"; }
           }
        }
        //end of A2
        // seat A3 started
        if (seat == "A3")
        {
           ui->pushButton_27->setChecked(false);

           ui->pushButton_27->setStyleSheet(defaultColor);
           if (qPA3.prepare("UPDATE sit SET Status = :status WHERE sitname = :sitname"))
           {
              qPA3.bindValue(":status", "not_booked");
              qPA3.bindValue(":sitname", "A3");
              if (!qPA3.exec()) {  qDebug() << "Error executing query: " << qPA3.lastError();}
              else { qDebug() << "Update successful"; }
           }
        }
        //end of A3
*/
     }
     //Update list
     QSqlQuery qCseat;
     QString NullString="00";
     qCseat.prepare("UPDATE user SET seatString = :newString WHERE Email = :qemail");
     qCseat.bindValue(":newString",NullString );
     qCseat.bindValue(":qemail",email);
     qDebug()<<email;
     if (!qCseat.exec()) {qDebug() << "Error executing query string: " << qCseat.lastError(); }
     else {qDebug() << "Update successful total string";}
     //Updating finished
     // Extracting done
     QMessageBox::information(this,tr("Refund request accepted"),tr("We are considering your request"));
     ui->stackedWidget->setCurrentIndex(0);
     }
     else {
     qDebug() << "The difference between day A and day B is greater than to 24 hours.";
     QMessageBox::warning(this,tr("Refund request "),tr( "The difference between day A and day B is greater than to 24 hours"));
     ui->stackedWidget->setCurrentIndex(0);

     }


}

void MainWindow::on_pushButton_59_clicked()
{
     ui->stackedWidget->setCurrentIndex(5);
}


void MainWindow::on_pushButton_60_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);

}


void MainWindow::on_pushButton_46_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_47_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_57_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);

}


void MainWindow::on_pushButton_58_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);

}


void MainWindow::on_pushButton_54_clicked()
{
     ui->stackedWidget->setCurrentIndex(10);
}


void MainWindow::on_pushButton_48_clicked()
{
     ui->stackedWidget->setCurrentIndex(12);

}


void MainWindow::on_pushButton_49_clicked()
{
     ui->stackedWidget->setCurrentIndex(11);

}


void MainWindow::on_pushButton_56_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);

}


void MainWindow::on_pushButton_53_clicked()
{
     ui->stackedWidget->setCurrentIndex(10);

}


void MainWindow::on_pushButton_51_clicked()
{
     ui->stackedWidget->setCurrentIndex(10);

}


void MainWindow::on_pushButton_50_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);

}


void MainWindow::on_pushButton_44_clicked()
{
     ui->stackedWidget->setCurrentIndex(14);

}


void MainWindow::on_pushButton_45_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);

}








void MainWindow::on_pushButton_31_clicked()
{

}







void MainWindow::on_pushButton_55_clicked()      ///seat control button
{
/*
     Login conn;
     QSqlQueryModel* modal=new QSqlQueryModel();

     conn.connopen();
     QSqlQuery* qry=new QSqlQuery(conn.mydb);
     qry->prepare("select sitname,Status from sit");
     qry->exec();
     modal->setQuery(*qry);
     ui->tableView->setModel(modal);

     //conn.connclose();

     qDebug()<<(modal->rowCount());*/
     QSqlQueryModel* modal=new QSqlQueryModel();
     QSqlQuery qry(db);
     qry.prepare("select sitname,Status from sit");
     qry.exec();
     modal->setQuery(qry);
     ui->tableView->setModel(modal);

}



void MainWindow::on_from_box_textActivated(const QString &arg1)
{
     fromS = arg1;
     qDebug() << fromS;
}


void MainWindow::on_to_box_textActivated(const QString &arg2)
{
     toS= arg2;
     qDebug() << toS;
}

void MainWindow::on_pushButton_63_clicked() //refund control button
{
   /*  Login conn1;
     QSqlQueryModel* modal1=new QSqlQueryModel();

     conn1.connopen();
     QSqlQuery* qry1=new QSqlQuery(conn1.mydb);
     qry1->prepare("select Af,ji,Ma from Refundlis");
     qry1->exec();
     modal1->setQuery(*qry1);
     ui->tableView_2->setModel(modal1);*/
    //
     QSqlQueryModel* modal1=new QSqlQueryModel();
     QSqlQuery qry1(db);
     qry1.prepare("select NAME,EMAIL,SEAT from Refundlist");
     qry1.exec();
     modal1->setQuery(qry1);
     ui->tableView_2->setModel(modal1);
     //
    //conn1.connclose();
    //qDebug()<<(modal->rowCount());
}
