#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QSqlDatabase>
#include<QDebug>
#include<QSqlQuery>
#include <QCoreApplication>
#include <QSqlError>
#include <QPushButton>
#include <QSqlError>
#include<QFileInfo>
#include<QtSql>
#include<Qtcore>
#include<QtGui>
#include<QDialog>
#include <QDateTime>
//
#include <QPrinter>
#include <QLabel>
#include <QPixmap>
#include <QTextDocument>
#include <QTextCursor>
#include <QFileDialog>
/////

namespace Ui{
class Login;
}
class Login : public QMainWindow
{
    Q_OBJECT
public:
    QSqlDatabase mydb,db;
/*
    void connclose()
    {
        db.close();
        db.removeDatabase(QSqlDatabase::defaultConnection);
    }*/
    /*
    bool connopen()
    {
        db=QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("C:/Users/User/OneDrive/Desktop/DurottoX/DurottoX/DurottoX/Durutto included all (2) (2) (2)/Durutto included all (2) (2)/Durutto included all/Durutto-final/duruttodatabase.db");
        db.open();
        if (db.isOpen()) {
            qDebug() << "Database is connected.";
        } else {
            qDebug() << "Database is not connected.";
        }
    }*/

};


//////
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void configureSeatButton(const QString &seatName, QPushButton *button, QString &var);
    void updateStatus( const QString &seatName, QPushButton *button, QString &flag);
    void refundSeat(const QString &seatName, QPushButton *button, QSqlQuery &query);
    void on_pushButton_3_clicked();

    void on_pushButton_13_clicked();


    void on_pushButton_10_clicked();

    void on_pushButton_14_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_21_clicked();

    void on_pushButton_24_clicked();

    void on_pushButton_87_clicked();

    void on_pushButton_4_toggled(bool checked);

    void on_pushButton_5_toggled(bool checked);

    void on_pushButton_27_toggled(bool checked);

    void on_pushButton_30_toggled(bool checked);

    void on_pushButton_29_toggled(bool checked);

    void on_pushButton_28_toggled(bool checked);

    void on_pushButton_32_toggled(bool checked);

    void on_pushButton_86_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_12_clicked();

    void on_pushButton_18_clicked();

    void on_pushButton_23_clicked();

    void on_pushButton_20_clicked();

    void on_pushButton_26_clicked();

    void on_pushButton_16_clicked();

    void on_pushButton_11_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_19_clicked();

    void on_pushButton_25_clicked();

    void on_pushButton_22_clicked();

    void on_pushButton_85_clicked();

    void on_pushButton_17_clicked();

    void on_pushButton_15_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_62_clicked();

    void on_pushButton_61_clicked();

    void on_pushButton_43_clicked();

    void on_pushButton_59_clicked();

    void on_pushButton_60_clicked();

    void on_pushButton_46_clicked();

    void on_pushButton_47_clicked();

    void on_pushButton_57_clicked();

    void on_pushButton_58_clicked();

    void on_pushButton_54_clicked();

    void on_pushButton_48_clicked();

    void on_pushButton_49_clicked();

    void on_pushButton_56_clicked();

    void on_pushButton_53_clicked();

    void on_pushButton_51_clicked();

    void on_pushButton_50_clicked();

    void on_pushButton_44_clicked();

    void on_pushButton_45_clicked();

    void on_pushButton_31_clicked();

    void on_pushButton_31_toggled(bool checked);

    void on_pushButton_33_toggled(bool checked);

    void on_pushButton_41_toggled(bool checked);

    void on_pushButton_40_toggled(bool checked);

    void on_pushButton_42_toggled(bool checked);

    void on_pushButton_55_clicked();

    void on_pushButton_35_toggled(bool checked);

    void on_pushButton_34_toggled(bool checked);

    void on_pushButton_36_toggled(bool checked);

    void on_pushButton_38_toggled(bool checked);

    void on_pushButton_37_toggled(bool checked);

    void on_pushButton_39_toggled(bool checked);

    void on_from_box_textActivated(const QString &arg1);

    void on_to_box_textActivated(const QString &arg1);

    void on_pushButton_63_clicked();

public slots:
    void checkPrinter();

private:
    Ui::MainWindow *ui;
    QString semail,sname,snum,spass;
    QString email,password;
    QSqlDatabase db;
    QString st,s,store,emailstore;
    QString username,contact,time;
    QString A1,A2,A3,B1,B2,B3,E1,E2,E3,C1,C2,C3,D1,D2,D3,F1,F2,F3;
    QString defaultColor,greenColor,redColor,ft,ft1,cl1,cl2,cl3,clw,qsFont;
    qint32 counter1,bookedSeatCount;
    QStringList TotalString;
    QString CurrentString,seatValue;
    QString fromS,toS;
    QString Date1;
    QString EmailX;
    qint64 currentTimeS;

};
#endif // MAINWINDOW_H

