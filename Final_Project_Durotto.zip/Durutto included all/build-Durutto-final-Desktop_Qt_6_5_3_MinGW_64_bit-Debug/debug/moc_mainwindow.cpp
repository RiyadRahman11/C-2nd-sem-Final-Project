/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Durutto-final/mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtGui/qscreen.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSLoginENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSLoginENDCLASS = QtMocHelpers::stringData(
    "Login"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSLoginENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[6];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSLoginENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSLoginENDCLASS_t qt_meta_stringdata_CLASSLoginENDCLASS = {
    {
        QT_MOC_LITERAL(0, 5)   // "Login"
    },
    "Login"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSLoginENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject Login::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSLoginENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSLoginENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSLoginENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Login, std::true_type>
    >,
    nullptr
} };

void Login::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *Login::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Login::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSLoginENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Login::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "configureSeatButton",
    "",
    "seatName",
    "QPushButton*",
    "button",
    "QString&",
    "var",
    "updateStatus",
    "flag",
    "refundSeat",
    "QSqlQuery&",
    "query",
    "on_pushButton_3_clicked",
    "on_pushButton_13_clicked",
    "on_pushButton_10_clicked",
    "on_pushButton_14_clicked",
    "on_pushButton_7_clicked",
    "on_pushButton_21_clicked",
    "on_pushButton_24_clicked",
    "on_pushButton_87_clicked",
    "on_pushButton_4_toggled",
    "checked",
    "on_pushButton_5_toggled",
    "on_pushButton_27_toggled",
    "on_pushButton_30_toggled",
    "on_pushButton_29_toggled",
    "on_pushButton_28_toggled",
    "on_pushButton_32_toggled",
    "on_pushButton_86_clicked",
    "on_pushButton_9_clicked",
    "on_pushButton_12_clicked",
    "on_pushButton_18_clicked",
    "on_pushButton_23_clicked",
    "on_pushButton_20_clicked",
    "on_pushButton_26_clicked",
    "on_pushButton_16_clicked",
    "on_pushButton_11_clicked",
    "on_pushButton_6_clicked",
    "on_pushButton_19_clicked",
    "on_pushButton_25_clicked",
    "on_pushButton_22_clicked",
    "on_pushButton_85_clicked",
    "on_pushButton_17_clicked",
    "on_pushButton_15_clicked",
    "on_pushButton_2_clicked",
    "on_pushButton_clicked",
    "on_pushButton_62_clicked",
    "on_pushButton_61_clicked",
    "on_pushButton_43_clicked",
    "on_pushButton_59_clicked",
    "on_pushButton_60_clicked",
    "on_pushButton_46_clicked",
    "on_pushButton_47_clicked",
    "on_pushButton_57_clicked",
    "on_pushButton_58_clicked",
    "on_pushButton_54_clicked",
    "on_pushButton_48_clicked",
    "on_pushButton_49_clicked",
    "on_pushButton_56_clicked",
    "on_pushButton_53_clicked",
    "on_pushButton_51_clicked",
    "on_pushButton_50_clicked",
    "on_pushButton_44_clicked",
    "on_pushButton_45_clicked",
    "on_pushButton_31_clicked",
    "on_pushButton_31_toggled",
    "on_pushButton_33_toggled",
    "on_pushButton_41_toggled",
    "on_pushButton_40_toggled",
    "on_pushButton_42_toggled",
    "on_pushButton_55_clicked",
    "on_pushButton_35_toggled",
    "on_pushButton_34_toggled",
    "on_pushButton_36_toggled",
    "on_pushButton_38_toggled",
    "on_pushButton_37_toggled",
    "on_pushButton_39_toggled",
    "on_from_box_textActivated",
    "arg1",
    "on_to_box_textActivated",
    "on_pushButton_63_clicked",
    "checkPrinter"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[166];
    char stringdata0[11];
    char stringdata1[20];
    char stringdata2[1];
    char stringdata3[9];
    char stringdata4[13];
    char stringdata5[7];
    char stringdata6[9];
    char stringdata7[4];
    char stringdata8[13];
    char stringdata9[5];
    char stringdata10[11];
    char stringdata11[11];
    char stringdata12[6];
    char stringdata13[24];
    char stringdata14[25];
    char stringdata15[25];
    char stringdata16[25];
    char stringdata17[24];
    char stringdata18[25];
    char stringdata19[25];
    char stringdata20[25];
    char stringdata21[24];
    char stringdata22[8];
    char stringdata23[24];
    char stringdata24[25];
    char stringdata25[25];
    char stringdata26[25];
    char stringdata27[25];
    char stringdata28[25];
    char stringdata29[25];
    char stringdata30[24];
    char stringdata31[25];
    char stringdata32[25];
    char stringdata33[25];
    char stringdata34[25];
    char stringdata35[25];
    char stringdata36[25];
    char stringdata37[25];
    char stringdata38[24];
    char stringdata39[25];
    char stringdata40[25];
    char stringdata41[25];
    char stringdata42[25];
    char stringdata43[25];
    char stringdata44[25];
    char stringdata45[24];
    char stringdata46[22];
    char stringdata47[25];
    char stringdata48[25];
    char stringdata49[25];
    char stringdata50[25];
    char stringdata51[25];
    char stringdata52[25];
    char stringdata53[25];
    char stringdata54[25];
    char stringdata55[25];
    char stringdata56[25];
    char stringdata57[25];
    char stringdata58[25];
    char stringdata59[25];
    char stringdata60[25];
    char stringdata61[25];
    char stringdata62[25];
    char stringdata63[25];
    char stringdata64[25];
    char stringdata65[25];
    char stringdata66[25];
    char stringdata67[25];
    char stringdata68[25];
    char stringdata69[25];
    char stringdata70[25];
    char stringdata71[25];
    char stringdata72[25];
    char stringdata73[25];
    char stringdata74[25];
    char stringdata75[25];
    char stringdata76[25];
    char stringdata77[25];
    char stringdata78[26];
    char stringdata79[5];
    char stringdata80[24];
    char stringdata81[25];
    char stringdata82[13];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 19),  // "configureSeatButton"
        QT_MOC_LITERAL(31, 0),  // ""
        QT_MOC_LITERAL(32, 8),  // "seatName"
        QT_MOC_LITERAL(41, 12),  // "QPushButton*"
        QT_MOC_LITERAL(54, 6),  // "button"
        QT_MOC_LITERAL(61, 8),  // "QString&"
        QT_MOC_LITERAL(70, 3),  // "var"
        QT_MOC_LITERAL(74, 12),  // "updateStatus"
        QT_MOC_LITERAL(87, 4),  // "flag"
        QT_MOC_LITERAL(92, 10),  // "refundSeat"
        QT_MOC_LITERAL(103, 10),  // "QSqlQuery&"
        QT_MOC_LITERAL(114, 5),  // "query"
        QT_MOC_LITERAL(120, 23),  // "on_pushButton_3_clicked"
        QT_MOC_LITERAL(144, 24),  // "on_pushButton_13_clicked"
        QT_MOC_LITERAL(169, 24),  // "on_pushButton_10_clicked"
        QT_MOC_LITERAL(194, 24),  // "on_pushButton_14_clicked"
        QT_MOC_LITERAL(219, 23),  // "on_pushButton_7_clicked"
        QT_MOC_LITERAL(243, 24),  // "on_pushButton_21_clicked"
        QT_MOC_LITERAL(268, 24),  // "on_pushButton_24_clicked"
        QT_MOC_LITERAL(293, 24),  // "on_pushButton_87_clicked"
        QT_MOC_LITERAL(318, 23),  // "on_pushButton_4_toggled"
        QT_MOC_LITERAL(342, 7),  // "checked"
        QT_MOC_LITERAL(350, 23),  // "on_pushButton_5_toggled"
        QT_MOC_LITERAL(374, 24),  // "on_pushButton_27_toggled"
        QT_MOC_LITERAL(399, 24),  // "on_pushButton_30_toggled"
        QT_MOC_LITERAL(424, 24),  // "on_pushButton_29_toggled"
        QT_MOC_LITERAL(449, 24),  // "on_pushButton_28_toggled"
        QT_MOC_LITERAL(474, 24),  // "on_pushButton_32_toggled"
        QT_MOC_LITERAL(499, 24),  // "on_pushButton_86_clicked"
        QT_MOC_LITERAL(524, 23),  // "on_pushButton_9_clicked"
        QT_MOC_LITERAL(548, 24),  // "on_pushButton_12_clicked"
        QT_MOC_LITERAL(573, 24),  // "on_pushButton_18_clicked"
        QT_MOC_LITERAL(598, 24),  // "on_pushButton_23_clicked"
        QT_MOC_LITERAL(623, 24),  // "on_pushButton_20_clicked"
        QT_MOC_LITERAL(648, 24),  // "on_pushButton_26_clicked"
        QT_MOC_LITERAL(673, 24),  // "on_pushButton_16_clicked"
        QT_MOC_LITERAL(698, 24),  // "on_pushButton_11_clicked"
        QT_MOC_LITERAL(723, 23),  // "on_pushButton_6_clicked"
        QT_MOC_LITERAL(747, 24),  // "on_pushButton_19_clicked"
        QT_MOC_LITERAL(772, 24),  // "on_pushButton_25_clicked"
        QT_MOC_LITERAL(797, 24),  // "on_pushButton_22_clicked"
        QT_MOC_LITERAL(822, 24),  // "on_pushButton_85_clicked"
        QT_MOC_LITERAL(847, 24),  // "on_pushButton_17_clicked"
        QT_MOC_LITERAL(872, 24),  // "on_pushButton_15_clicked"
        QT_MOC_LITERAL(897, 23),  // "on_pushButton_2_clicked"
        QT_MOC_LITERAL(921, 21),  // "on_pushButton_clicked"
        QT_MOC_LITERAL(943, 24),  // "on_pushButton_62_clicked"
        QT_MOC_LITERAL(968, 24),  // "on_pushButton_61_clicked"
        QT_MOC_LITERAL(993, 24),  // "on_pushButton_43_clicked"
        QT_MOC_LITERAL(1018, 24),  // "on_pushButton_59_clicked"
        QT_MOC_LITERAL(1043, 24),  // "on_pushButton_60_clicked"
        QT_MOC_LITERAL(1068, 24),  // "on_pushButton_46_clicked"
        QT_MOC_LITERAL(1093, 24),  // "on_pushButton_47_clicked"
        QT_MOC_LITERAL(1118, 24),  // "on_pushButton_57_clicked"
        QT_MOC_LITERAL(1143, 24),  // "on_pushButton_58_clicked"
        QT_MOC_LITERAL(1168, 24),  // "on_pushButton_54_clicked"
        QT_MOC_LITERAL(1193, 24),  // "on_pushButton_48_clicked"
        QT_MOC_LITERAL(1218, 24),  // "on_pushButton_49_clicked"
        QT_MOC_LITERAL(1243, 24),  // "on_pushButton_56_clicked"
        QT_MOC_LITERAL(1268, 24),  // "on_pushButton_53_clicked"
        QT_MOC_LITERAL(1293, 24),  // "on_pushButton_51_clicked"
        QT_MOC_LITERAL(1318, 24),  // "on_pushButton_50_clicked"
        QT_MOC_LITERAL(1343, 24),  // "on_pushButton_44_clicked"
        QT_MOC_LITERAL(1368, 24),  // "on_pushButton_45_clicked"
        QT_MOC_LITERAL(1393, 24),  // "on_pushButton_31_clicked"
        QT_MOC_LITERAL(1418, 24),  // "on_pushButton_31_toggled"
        QT_MOC_LITERAL(1443, 24),  // "on_pushButton_33_toggled"
        QT_MOC_LITERAL(1468, 24),  // "on_pushButton_41_toggled"
        QT_MOC_LITERAL(1493, 24),  // "on_pushButton_40_toggled"
        QT_MOC_LITERAL(1518, 24),  // "on_pushButton_42_toggled"
        QT_MOC_LITERAL(1543, 24),  // "on_pushButton_55_clicked"
        QT_MOC_LITERAL(1568, 24),  // "on_pushButton_35_toggled"
        QT_MOC_LITERAL(1593, 24),  // "on_pushButton_34_toggled"
        QT_MOC_LITERAL(1618, 24),  // "on_pushButton_36_toggled"
        QT_MOC_LITERAL(1643, 24),  // "on_pushButton_38_toggled"
        QT_MOC_LITERAL(1668, 24),  // "on_pushButton_37_toggled"
        QT_MOC_LITERAL(1693, 24),  // "on_pushButton_39_toggled"
        QT_MOC_LITERAL(1718, 25),  // "on_from_box_textActivated"
        QT_MOC_LITERAL(1744, 4),  // "arg1"
        QT_MOC_LITERAL(1749, 23),  // "on_to_box_textActivated"
        QT_MOC_LITERAL(1773, 24),  // "on_pushButton_63_clicked"
        QT_MOC_LITERAL(1798, 12)   // "checkPrinter"
    },
    "MainWindow",
    "configureSeatButton",
    "",
    "seatName",
    "QPushButton*",
    "button",
    "QString&",
    "var",
    "updateStatus",
    "flag",
    "refundSeat",
    "QSqlQuery&",
    "query",
    "on_pushButton_3_clicked",
    "on_pushButton_13_clicked",
    "on_pushButton_10_clicked",
    "on_pushButton_14_clicked",
    "on_pushButton_7_clicked",
    "on_pushButton_21_clicked",
    "on_pushButton_24_clicked",
    "on_pushButton_87_clicked",
    "on_pushButton_4_toggled",
    "checked",
    "on_pushButton_5_toggled",
    "on_pushButton_27_toggled",
    "on_pushButton_30_toggled",
    "on_pushButton_29_toggled",
    "on_pushButton_28_toggled",
    "on_pushButton_32_toggled",
    "on_pushButton_86_clicked",
    "on_pushButton_9_clicked",
    "on_pushButton_12_clicked",
    "on_pushButton_18_clicked",
    "on_pushButton_23_clicked",
    "on_pushButton_20_clicked",
    "on_pushButton_26_clicked",
    "on_pushButton_16_clicked",
    "on_pushButton_11_clicked",
    "on_pushButton_6_clicked",
    "on_pushButton_19_clicked",
    "on_pushButton_25_clicked",
    "on_pushButton_22_clicked",
    "on_pushButton_85_clicked",
    "on_pushButton_17_clicked",
    "on_pushButton_15_clicked",
    "on_pushButton_2_clicked",
    "on_pushButton_clicked",
    "on_pushButton_62_clicked",
    "on_pushButton_61_clicked",
    "on_pushButton_43_clicked",
    "on_pushButton_59_clicked",
    "on_pushButton_60_clicked",
    "on_pushButton_46_clicked",
    "on_pushButton_47_clicked",
    "on_pushButton_57_clicked",
    "on_pushButton_58_clicked",
    "on_pushButton_54_clicked",
    "on_pushButton_48_clicked",
    "on_pushButton_49_clicked",
    "on_pushButton_56_clicked",
    "on_pushButton_53_clicked",
    "on_pushButton_51_clicked",
    "on_pushButton_50_clicked",
    "on_pushButton_44_clicked",
    "on_pushButton_45_clicked",
    "on_pushButton_31_clicked",
    "on_pushButton_31_toggled",
    "on_pushButton_33_toggled",
    "on_pushButton_41_toggled",
    "on_pushButton_40_toggled",
    "on_pushButton_42_toggled",
    "on_pushButton_55_clicked",
    "on_pushButton_35_toggled",
    "on_pushButton_34_toggled",
    "on_pushButton_36_toggled",
    "on_pushButton_38_toggled",
    "on_pushButton_37_toggled",
    "on_pushButton_39_toggled",
    "on_from_box_textActivated",
    "arg1",
    "on_to_box_textActivated",
    "on_pushButton_63_clicked",
    "checkPrinter"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      71,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    3,  440,    2, 0x08,    1 /* Private */,
       8,    3,  447,    2, 0x08,    5 /* Private */,
      10,    3,  454,    2, 0x08,    9 /* Private */,
      13,    0,  461,    2, 0x08,   13 /* Private */,
      14,    0,  462,    2, 0x08,   14 /* Private */,
      15,    0,  463,    2, 0x08,   15 /* Private */,
      16,    0,  464,    2, 0x08,   16 /* Private */,
      17,    0,  465,    2, 0x08,   17 /* Private */,
      18,    0,  466,    2, 0x08,   18 /* Private */,
      19,    0,  467,    2, 0x08,   19 /* Private */,
      20,    0,  468,    2, 0x08,   20 /* Private */,
      21,    1,  469,    2, 0x08,   21 /* Private */,
      23,    1,  472,    2, 0x08,   23 /* Private */,
      24,    1,  475,    2, 0x08,   25 /* Private */,
      25,    1,  478,    2, 0x08,   27 /* Private */,
      26,    1,  481,    2, 0x08,   29 /* Private */,
      27,    1,  484,    2, 0x08,   31 /* Private */,
      28,    1,  487,    2, 0x08,   33 /* Private */,
      29,    0,  490,    2, 0x08,   35 /* Private */,
      30,    0,  491,    2, 0x08,   36 /* Private */,
      31,    0,  492,    2, 0x08,   37 /* Private */,
      32,    0,  493,    2, 0x08,   38 /* Private */,
      33,    0,  494,    2, 0x08,   39 /* Private */,
      34,    0,  495,    2, 0x08,   40 /* Private */,
      35,    0,  496,    2, 0x08,   41 /* Private */,
      36,    0,  497,    2, 0x08,   42 /* Private */,
      37,    0,  498,    2, 0x08,   43 /* Private */,
      38,    0,  499,    2, 0x08,   44 /* Private */,
      39,    0,  500,    2, 0x08,   45 /* Private */,
      40,    0,  501,    2, 0x08,   46 /* Private */,
      41,    0,  502,    2, 0x08,   47 /* Private */,
      42,    0,  503,    2, 0x08,   48 /* Private */,
      43,    0,  504,    2, 0x08,   49 /* Private */,
      44,    0,  505,    2, 0x08,   50 /* Private */,
      45,    0,  506,    2, 0x08,   51 /* Private */,
      46,    0,  507,    2, 0x08,   52 /* Private */,
      47,    0,  508,    2, 0x08,   53 /* Private */,
      48,    0,  509,    2, 0x08,   54 /* Private */,
      49,    0,  510,    2, 0x08,   55 /* Private */,
      50,    0,  511,    2, 0x08,   56 /* Private */,
      51,    0,  512,    2, 0x08,   57 /* Private */,
      52,    0,  513,    2, 0x08,   58 /* Private */,
      53,    0,  514,    2, 0x08,   59 /* Private */,
      54,    0,  515,    2, 0x08,   60 /* Private */,
      55,    0,  516,    2, 0x08,   61 /* Private */,
      56,    0,  517,    2, 0x08,   62 /* Private */,
      57,    0,  518,    2, 0x08,   63 /* Private */,
      58,    0,  519,    2, 0x08,   64 /* Private */,
      59,    0,  520,    2, 0x08,   65 /* Private */,
      60,    0,  521,    2, 0x08,   66 /* Private */,
      61,    0,  522,    2, 0x08,   67 /* Private */,
      62,    0,  523,    2, 0x08,   68 /* Private */,
      63,    0,  524,    2, 0x08,   69 /* Private */,
      64,    0,  525,    2, 0x08,   70 /* Private */,
      65,    0,  526,    2, 0x08,   71 /* Private */,
      66,    1,  527,    2, 0x08,   72 /* Private */,
      67,    1,  530,    2, 0x08,   74 /* Private */,
      68,    1,  533,    2, 0x08,   76 /* Private */,
      69,    1,  536,    2, 0x08,   78 /* Private */,
      70,    1,  539,    2, 0x08,   80 /* Private */,
      71,    0,  542,    2, 0x08,   82 /* Private */,
      72,    1,  543,    2, 0x08,   83 /* Private */,
      73,    1,  546,    2, 0x08,   85 /* Private */,
      74,    1,  549,    2, 0x08,   87 /* Private */,
      75,    1,  552,    2, 0x08,   89 /* Private */,
      76,    1,  555,    2, 0x08,   91 /* Private */,
      77,    1,  558,    2, 0x08,   93 /* Private */,
      78,    1,  561,    2, 0x08,   95 /* Private */,
      80,    1,  564,    2, 0x08,   97 /* Private */,
      81,    0,  567,    2, 0x08,   99 /* Private */,
      82,    0,  568,    2, 0x0a,  100 /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, 0x80000000 | 4, 0x80000000 | 6,    3,    5,    7,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 4, 0x80000000 | 6,    3,    5,    9,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 4, 0x80000000 | 11,    3,    5,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::Bool,   22,
    QMetaType::Void, QMetaType::QString,   79,
    QMetaType::Void, QMetaType::QString,   79,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'configureSeatButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPushButton *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        // method 'updateStatus'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPushButton *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        // method 'refundSeat'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPushButton *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QSqlQuery &, std::false_type>,
        // method 'on_pushButton_3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_13_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_10_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_14_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_7_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_21_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_24_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_87_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_4_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_5_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_27_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_30_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_29_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_28_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_32_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_86_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_9_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_12_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_18_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_23_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_20_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_26_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_16_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_11_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_6_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_19_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_25_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_22_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_85_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_17_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_15_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_62_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_61_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_43_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_59_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_60_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_46_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_47_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_57_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_58_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_54_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_48_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_49_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_56_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_53_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_51_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_50_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_44_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_45_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_31_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_31_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_33_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_41_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_40_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_42_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_55_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_35_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_34_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_36_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_38_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_37_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_39_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_from_box_textActivated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_to_box_textActivated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_pushButton_63_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'checkPrinter'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->configureSeatButton((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPushButton*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString&>>(_a[3]))); break;
        case 1: _t->updateStatus((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPushButton*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString&>>(_a[3]))); break;
        case 2: _t->refundSeat((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPushButton*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QSqlQuery&>>(_a[3]))); break;
        case 3: _t->on_pushButton_3_clicked(); break;
        case 4: _t->on_pushButton_13_clicked(); break;
        case 5: _t->on_pushButton_10_clicked(); break;
        case 6: _t->on_pushButton_14_clicked(); break;
        case 7: _t->on_pushButton_7_clicked(); break;
        case 8: _t->on_pushButton_21_clicked(); break;
        case 9: _t->on_pushButton_24_clicked(); break;
        case 10: _t->on_pushButton_87_clicked(); break;
        case 11: _t->on_pushButton_4_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 12: _t->on_pushButton_5_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 13: _t->on_pushButton_27_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 14: _t->on_pushButton_30_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 15: _t->on_pushButton_29_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 16: _t->on_pushButton_28_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 17: _t->on_pushButton_32_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 18: _t->on_pushButton_86_clicked(); break;
        case 19: _t->on_pushButton_9_clicked(); break;
        case 20: _t->on_pushButton_12_clicked(); break;
        case 21: _t->on_pushButton_18_clicked(); break;
        case 22: _t->on_pushButton_23_clicked(); break;
        case 23: _t->on_pushButton_20_clicked(); break;
        case 24: _t->on_pushButton_26_clicked(); break;
        case 25: _t->on_pushButton_16_clicked(); break;
        case 26: _t->on_pushButton_11_clicked(); break;
        case 27: _t->on_pushButton_6_clicked(); break;
        case 28: _t->on_pushButton_19_clicked(); break;
        case 29: _t->on_pushButton_25_clicked(); break;
        case 30: _t->on_pushButton_22_clicked(); break;
        case 31: _t->on_pushButton_85_clicked(); break;
        case 32: _t->on_pushButton_17_clicked(); break;
        case 33: _t->on_pushButton_15_clicked(); break;
        case 34: _t->on_pushButton_2_clicked(); break;
        case 35: _t->on_pushButton_clicked(); break;
        case 36: _t->on_pushButton_62_clicked(); break;
        case 37: _t->on_pushButton_61_clicked(); break;
        case 38: _t->on_pushButton_43_clicked(); break;
        case 39: _t->on_pushButton_59_clicked(); break;
        case 40: _t->on_pushButton_60_clicked(); break;
        case 41: _t->on_pushButton_46_clicked(); break;
        case 42: _t->on_pushButton_47_clicked(); break;
        case 43: _t->on_pushButton_57_clicked(); break;
        case 44: _t->on_pushButton_58_clicked(); break;
        case 45: _t->on_pushButton_54_clicked(); break;
        case 46: _t->on_pushButton_48_clicked(); break;
        case 47: _t->on_pushButton_49_clicked(); break;
        case 48: _t->on_pushButton_56_clicked(); break;
        case 49: _t->on_pushButton_53_clicked(); break;
        case 50: _t->on_pushButton_51_clicked(); break;
        case 51: _t->on_pushButton_50_clicked(); break;
        case 52: _t->on_pushButton_44_clicked(); break;
        case 53: _t->on_pushButton_45_clicked(); break;
        case 54: _t->on_pushButton_31_clicked(); break;
        case 55: _t->on_pushButton_31_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 56: _t->on_pushButton_33_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 57: _t->on_pushButton_41_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 58: _t->on_pushButton_40_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 59: _t->on_pushButton_42_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 60: _t->on_pushButton_55_clicked(); break;
        case 61: _t->on_pushButton_35_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 62: _t->on_pushButton_34_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 63: _t->on_pushButton_36_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 64: _t->on_pushButton_38_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 65: _t->on_pushButton_37_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 66: _t->on_pushButton_39_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 67: _t->on_from_box_textActivated((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 68: _t->on_to_box_textActivated((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 69: _t->on_pushButton_63_clicked(); break;
        case 70: _t->checkPrinter(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QPushButton* >(); break;
            }
            break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QPushButton* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QPushButton* >(); break;
            }
            break;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 71)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 71;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 71)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 71;
    }
    return _id;
}
QT_WARNING_POP
