/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QStackedWidget *stackedWidget;
    QWidget *start;
    QLabel *label_2;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QPushButton *pushButton_3;
    QLabel *label;
    QLabel *label_3;
    QLabel *label_50;
    QPushButton *pushButton_54;
    QPushButton *pushButton_56;
    QWidget *Developers;
    QLabel *label_86;
    QLabel *label_87;
    QPushButton *pushButton_57;
    QPushButton *pushButton_58;
    QLabel *label_88;
    QLabel *label_89;
    QWidget *refund;
    QPushButton *pushButton_17;
    QLabel *label_26;
    QTextBrowser *textBrowser_2;
    QLabel *label_27;
    QLabel *label_22;
    QPushButton *pushButton_18;
    QLabel *label_28;
    QLabel *label_57;
    QWidget *destination;
    QLabel *label_20;
    QLabel *label_29;
    QLabel *logomain_4;
    QPushButton *pushButton_14;
    QLabel *label_32;
    QPushButton *pushButton_19;
    QPushButton *pushButton_20;
    QLabel *label_33;
    QLabel *label_34;
    QLabel *label_31;
    QLabel *label_54;
    QComboBox *from_box;
    QComboBox *to_box;
    QDateEdit *dateEdit;
    QWidget *signup;
    QLabel *label_4;
    QLabel *label_6;
    QPushButton *pushButton_6;
    QLabel *label_7;
    QLineEdit *lineEdit;
    QLabel *label_8;
    QLabel *label_9;
    QLineEdit *lineEdit_2;
    QLabel *label_10;
    QLineEdit *lineEdit_3;
    QLabel *label_11;
    QLineEdit *lineEdit_4;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QLabel *label_5;
    QLabel *label_59;
    QWidget *signin;
    QLabel *label_14;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QPushButton *pushButton_12;
    QLineEdit *lineEdit_7;
    QPushButton *pushButton_13;
    QLineEdit *lineEdit_8;
    QLabel *label_19;
    QLabel *label_18;
    QLabel *label_58;
    QWidget *payment;
    QLabel *label_35;
    QLabel *label_36;
    QLabel *label_37;
    QPushButton *pushButton_21;
    QLabel *label_39;
    QPushButton *pushButton_22;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_12;
    QPushButton *pushButton_23;
    QLabel *label_40;
    QLabel *label_38;
    QLabel *label_56;
    QWidget *busseat;
    QLabel *label_43;
    QPushButton *pushButton_24;
    QLabel *logomain_2;
    QLabel *label_45;
    QLabel *label_46;
    QPushButton *pushButton_25;
    QLabel *label_47;
    QPushButton *pushButton_26;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_28;
    QPushButton *pushButton_29;
    QPushButton *pushButton_30;
    QPushButton *pushButton_31;
    QPushButton *pushButton_32;
    QPushButton *pushButton_33;
    QPushButton *pushButton_27;
    QPushButton *pushButton_34;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QPushButton *pushButton_37;
    QPushButton *pushButton_38;
    QPushButton *pushButton_39;
    QPushButton *pushButton_40;
    QPushButton *pushButton_41;
    QPushButton *pushButton_42;
    QLabel *label_12;
    QLabel *label_48;
    QTextBrowser *textBrowser_3;
    QLabel *label_49;
    QLabel *label_42;
    QLabel *label_53;
    QLabel *label_336;
    QLabel *label_337;
    QLabel *Time1;
    QWidget *invoice;
    QPushButton *pushButton_85;
    QLabel *logomain;
    QLabel *label_96;
    QLabel *label_97;
    QPushButton *pushButton_86;
    QPushButton *pushButton_87;
    QLabel *label_98;
    QLabel *label_100;
    QLabel *label_101;
    QLabel *label_102;
    QLabel *label_103;
    QLabel *label_104;
    QLabel *label_13;
    QLabel *label_44;
    QLabel *lb_inv_contact;
    QLabel *lb_inv_Email;
    QLabel *lb_inv_Paid;
    QLabel *lb_inv_Seats;
    QLabel *lb_inv_Date;
    QLabel *label_51;
    QLabel *label_55;
    QLabel *label_332;
    QLabel *label_333;
    QLabel *label_334;
    QLabel *label_335;
    QWidget *refundapply;
    QLabel *label_60;
    QLabel *label_61;
    QLabel *label_63;
    QLabel *label_64;
    QLabel *label_65;
    QPushButton *pushButton_43;
    QLineEdit *lineEdit_13;
    QLabel *label_66;
    QPushButton *pushButton_44;
    QPushButton *pushButton_45;
    QLabel *label_67;
    QLabel *label_68;
    QLineEdit *lineEdit_14;
    QLineEdit *lineEdit_15;
    QWidget *admin;
    QLabel *label_41;
    QLabel *label_70;
    QLabel *label_71;
    QPushButton *pushButton_46;
    QLabel *label_72;
    QPushButton *pushButton_47;
    QLabel *label_74;
    QPushButton *pushButton_48;
    QPushButton *pushButton_49;
    QWidget *Seatcontrol;
    QLabel *label_69;
    QPushButton *pushButton_50;
    QPushButton *pushButton_51;
    QLabel *label_75;
    QLabel *label_76;
    QLabel *label_77;
    QLabel *label_78;
    QLabel *label_73;
    QTableView *tableView;
    QPushButton *pushButton_55;
    QWidget *Refundcontrol;
    QLabel *label_79;
    QPushButton *pushButton_52;
    QLabel *label_80;
    QLabel *label_81;
    QPushButton *pushButton_53;
    QLabel *label_82;
    QLabel *label_83;
    QLabel *label_84;
    QTableView *tableView_2;
    QPushButton *pushButton_63;
    QWidget *aboutus;
    QPushButton *pushButton_15;
    QLabel *label_21;
    QLabel *label_23;
    QPushButton *pushButton_16;
    QLabel *logomain_3;
    QTextBrowser *textBrowser;
    QLabel *label_24;
    QLabel *label_52;
    QWidget *userdashboard;
    QPushButton *pushButton_59;
    QLabel *label_91;
    QLabel *label_92;
    QPushButton *pushButton_60;
    QLabel *label_93;
    QLabel *label_25;
    QLabel *label_30;
    QLabel *label_90;
    QLabel *label_94;
    QPushButton *pushButton_61;
    QLabel *label_95;
    QLabel *label_99;
    QPushButton *pushButton_62;
    QLabel *label_62;
    QLabel *label_85;
    QLabel *label_105;
    QLabel *label_106;
    QWidget *invoiceprint;
    QLabel *label_319;
    QLabel *label_320;
    QLabel *label_321;
    QLabel *label_322;
    QLabel *label_323;
    QLabel *label_324;
    QLabel *label_325;
    QLabel *label_326;
    QLabel *lb_inv_Date_4;
    QLabel *logomain_13;
    QLabel *label_327;
    QLabel *lb_inv_Email_4;
    QLabel *lb_inv_contact_4;
    QLabel *lb_inv_Paid_4;
    QLabel *label_328;
    QLabel *label_329;
    QLabel *lb_inv_Seats_4;
    QLabel *label_330;
    QWidget *page;
    QComboBox *comboBox;
    QLabel *label_331;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(900, 600);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName("stackedWidget");
        stackedWidget->setGeometry(QRect(0, 0, 900, 600));
        stackedWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(7, 151, 145);"));
        start = new QWidget();
        start->setObjectName("start");
        label_2 = new QLabel(start);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(190, 80, 531, 431));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_2->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_2->setScaledContents(true);
        pushButton_2 = new QPushButton(start);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(330, 180, 75, 24));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        pushButton = new QPushButton(start);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(410, 180, 91, 24));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        pushButton_3 = new QPushButton(start);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(410, 450, 101, 31));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../secured.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_3->setIcon(icon);
        label = new QLabel(start);
        label->setObjectName("label");
        label->setGeometry(QRect(230, 220, 441, 201));
        label->setPixmap(QPixmap(QString::fromUtf8("../../../../DURUTT~1/DURUTT~1/DURUTT~1/INTERN~1.JPG")));
        label->setScaledContents(true);
        label_3 = new QLabel(start);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(370, 100, 181, 91));
        label_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_3->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_3->setScaledContents(true);
        label_50 = new QLabel(start);
        label_50->setObjectName("label_50");
        label_50->setGeometry(QRect(0, -20, 900, 600));
        label_50->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_50->setScaledContents(true);
        pushButton_54 = new QPushButton(start);
        pushButton_54->setObjectName("pushButton_54");
        pushButton_54->setGeometry(QRect(760, 30, 101, 31));
        pushButton_54->setStyleSheet(QString::fromUtf8("\n"
"font: 700 9pt \"Segoe UI\";\n"
"background-color: rgb(5, 105, 116);\n"
"color: rgb(255, 255, 255);"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../2206248.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_54->setIcon(icon1);
        pushButton_56 = new QPushButton(start);
        pushButton_56->setObjectName("pushButton_56");
        pushButton_56->setGeometry(QRect(510, 180, 91, 24));
        pushButton_56->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        stackedWidget->addWidget(start);
        label_50->raise();
        label_2->raise();
        pushButton_3->raise();
        label->raise();
        label_3->raise();
        pushButton->raise();
        pushButton_2->raise();
        pushButton_54->raise();
        pushButton_56->raise();
        Developers = new QWidget();
        Developers->setObjectName("Developers");
        label_86 = new QLabel(Developers);
        label_86->setObjectName("label_86");
        label_86->setGeometry(QRect(190, 80, 531, 431));
        label_86->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_86->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_86->setScaledContents(true);
        label_87 = new QLabel(Developers);
        label_87->setObjectName("label_87");
        label_87->setGeometry(QRect(210, 100, 181, 91));
        label_87->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_87->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_87->setScaledContents(true);
        pushButton_57 = new QPushButton(Developers);
        pushButton_57->setObjectName("pushButton_57");
        pushButton_57->setGeometry(QRect(30, 30, 75, 24));
        pushButton_57->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        pushButton_58 = new QPushButton(Developers);
        pushButton_58->setObjectName("pushButton_58");
        pushButton_58->setGeometry(QRect(800, 30, 75, 24));
        pushButton_58->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_88 = new QLabel(Developers);
        label_88->setObjectName("label_88");
        label_88->setGeometry(QRect(0, -20, 900, 600));
        label_88->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_88->setScaledContents(true);
        label_89 = new QLabel(Developers);
        label_89->setObjectName("label_89");
        label_89->setGeometry(QRect(220, 180, 481, 271));
        label_89->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_89->setPixmap(QPixmap(QString::fromUtf8("../developers.jpg")));
        label_89->setScaledContents(true);
        stackedWidget->addWidget(Developers);
        label_88->raise();
        label_86->raise();
        label_87->raise();
        pushButton_57->raise();
        pushButton_58->raise();
        label_89->raise();
        refund = new QWidget();
        refund->setObjectName("refund");
        pushButton_17 = new QPushButton(refund);
        pushButton_17->setObjectName("pushButton_17");
        pushButton_17->setGeometry(QRect(30, 30, 75, 24));
        pushButton_17->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_26 = new QLabel(refund);
        label_26->setObjectName("label_26");
        label_26->setGeometry(QRect(630, 120, 61, 61));
        label_26->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_26->setPixmap(QPixmap(QString::fromUtf8("../secured.png")));
        label_26->setScaledContents(true);
        textBrowser_2 = new QTextBrowser(refund);
        textBrowser_2->setObjectName("textBrowser_2");
        textBrowser_2->setGeometry(QRect(220, 220, 471, 161));
        textBrowser_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 700 8pt \"Segoe UI\";"));
        label_27 = new QLabel(refund);
        label_27->setObjectName("label_27");
        label_27->setGeometry(QRect(210, 100, 181, 91));
        label_27->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_27->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_27->setScaledContents(true);
        label_22 = new QLabel(refund);
        label_22->setObjectName("label_22");
        label_22->setGeometry(QRect(500, 180, 201, 31));
        label_22->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        pushButton_18 = new QPushButton(refund);
        pushButton_18->setObjectName("pushButton_18");
        pushButton_18->setGeometry(QRect(800, 30, 75, 24));
        pushButton_18->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_28 = new QLabel(refund);
        label_28->setObjectName("label_28");
        label_28->setGeometry(QRect(190, 80, 531, 431));
        label_28->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_28->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_28->setScaledContents(true);
        label_57 = new QLabel(refund);
        label_57->setObjectName("label_57");
        label_57->setGeometry(QRect(0, -20, 900, 600));
        label_57->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_57->setScaledContents(true);
        stackedWidget->addWidget(refund);
        label_57->raise();
        label_28->raise();
        pushButton_17->raise();
        label_26->raise();
        textBrowser_2->raise();
        label_27->raise();
        label_22->raise();
        pushButton_18->raise();
        destination = new QWidget();
        destination->setObjectName("destination");
        label_20 = new QLabel(destination);
        label_20->setObjectName("label_20");
        label_20->setGeometry(QRect(230, 220, 211, 201));
        label_20->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_20->setPixmap(QPixmap(QString::fromUtf8("../64be4248-e9b0-417d-90ec-6afe331a0ec4.png")));
        label_20->setScaledContents(true);
        label_29 = new QLabel(destination);
        label_29->setObjectName("label_29");
        label_29->setGeometry(QRect(470, 260, 51, 16));
        label_29->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        logomain_4 = new QLabel(destination);
        logomain_4->setObjectName("logomain_4");
        logomain_4->setGeometry(QRect(210, 100, 181, 91));
        logomain_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        logomain_4->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        logomain_4->setScaledContents(true);
        pushButton_14 = new QPushButton(destination);
        pushButton_14->setObjectName("pushButton_14");
        pushButton_14->setGeometry(QRect(510, 420, 111, 24));
        pushButton_14->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        label_32 = new QLabel(destination);
        label_32->setObjectName("label_32");
        label_32->setGeometry(QRect(470, 310, 71, 16));
        label_32->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        pushButton_19 = new QPushButton(destination);
        pushButton_19->setObjectName("pushButton_19");
        pushButton_19->setGeometry(QRect(30, 30, 75, 24));
        pushButton_19->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        pushButton_20 = new QPushButton(destination);
        pushButton_20->setObjectName("pushButton_20");
        pushButton_20->setGeometry(QRect(800, 30, 75, 24));
        pushButton_20->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_33 = new QLabel(destination);
        label_33->setObjectName("label_33");
        label_33->setGeometry(QRect(470, 220, 211, 31));
        label_33->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        label_34 = new QLabel(destination);
        label_34->setObjectName("label_34");
        label_34->setGeometry(QRect(470, 360, 81, 16));
        label_34->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_31 = new QLabel(destination);
        label_31->setObjectName("label_31");
        label_31->setGeometry(QRect(190, 80, 531, 431));
        label_31->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_31->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_31->setScaledContents(true);
        label_54 = new QLabel(destination);
        label_54->setObjectName("label_54");
        label_54->setGeometry(QRect(0, -20, 900, 600));
        label_54->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_54->setScaledContents(true);
        from_box = new QComboBox(destination);
        from_box->setObjectName("from_box");
        from_box->setGeometry(QRect(470, 280, 201, 24));
        from_box->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        to_box = new QComboBox(destination);
        to_box->setObjectName("to_box");
        to_box->setGeometry(QRect(470, 330, 201, 24));
        to_box->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        dateEdit = new QDateEdit(destination);
        dateEdit->setObjectName("dateEdit");
        dateEdit->setGeometry(QRect(470, 380, 110, 25));
        dateEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        stackedWidget->addWidget(destination);
        label_54->raise();
        label_31->raise();
        label_20->raise();
        logomain_4->raise();
        pushButton_19->raise();
        pushButton_20->raise();
        label_33->raise();
        pushButton_14->raise();
        label_34->raise();
        label_32->raise();
        label_29->raise();
        from_box->raise();
        to_box->raise();
        dateEdit->raise();
        signup = new QWidget();
        signup->setObjectName("signup");
        label_4 = new QLabel(signup);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(210, 230, 271, 191));
        label_4->setPixmap(QPixmap(QString::fromUtf8("../83a8517050500a23ff0d546bea883af6.jpg")));
        label_4->setScaledContents(true);
        label_6 = new QLabel(signup);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(210, 100, 181, 91));
        label_6->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_6->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_6->setScaledContents(true);
        pushButton_6 = new QPushButton(signup);
        pushButton_6->setObjectName("pushButton_6");
        pushButton_6->setGeometry(QRect(30, 30, 75, 24));
        pushButton_6->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_7 = new QLabel(signup);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(530, 170, 101, 31));
        label_7->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        lineEdit = new QLineEdit(signup);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setGeometry(QRect(490, 240, 171, 22));
        lineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_8 = new QLabel(signup);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(490, 220, 51, 16));
        label_8->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_9 = new QLabel(signup);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(490, 270, 51, 16));
        label_9->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        lineEdit_2 = new QLineEdit(signup);
        lineEdit_2->setObjectName("lineEdit_2");
        lineEdit_2->setGeometry(QRect(490, 290, 171, 22));
        lineEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_10 = new QLabel(signup);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(490, 320, 51, 16));
        label_10->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        lineEdit_3 = new QLineEdit(signup);
        lineEdit_3->setObjectName("lineEdit_3");
        lineEdit_3->setGeometry(QRect(490, 340, 171, 22));
        lineEdit_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_11 = new QLabel(signup);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(490, 370, 71, 16));
        label_11->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        lineEdit_4 = new QLineEdit(signup);
        lineEdit_4->setObjectName("lineEdit_4");
        lineEdit_4->setGeometry(QRect(490, 390, 171, 22));
        lineEdit_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        pushButton_7 = new QPushButton(signup);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setGeometry(QRect(590, 420, 71, 24));
        pushButton_7->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        pushButton_8 = new QPushButton(signup);
        pushButton_8->setObjectName("pushButton_8");
        pushButton_8->setGeometry(QRect(490, 420, 71, 24));
        pushButton_8->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        pushButton_9 = new QPushButton(signup);
        pushButton_9->setObjectName("pushButton_9");
        pushButton_9->setGeometry(QRect(800, 30, 75, 24));
        pushButton_9->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_5 = new QLabel(signup);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(190, 80, 531, 431));
        label_5->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_5->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_5->setScaledContents(true);
        label_59 = new QLabel(signup);
        label_59->setObjectName("label_59");
        label_59->setGeometry(QRect(0, -20, 900, 600));
        label_59->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_59->setScaledContents(true);
        stackedWidget->addWidget(signup);
        label_59->raise();
        label_5->raise();
        label_4->raise();
        label_6->raise();
        pushButton_6->raise();
        label_7->raise();
        lineEdit->raise();
        label_8->raise();
        label_9->raise();
        lineEdit_2->raise();
        label_10->raise();
        lineEdit_3->raise();
        label_11->raise();
        lineEdit_4->raise();
        pushButton_7->raise();
        pushButton_8->raise();
        pushButton_9->raise();
        signin = new QWidget();
        signin->setObjectName("signin");
        label_14 = new QLabel(signin);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(500, 270, 51, 16));
        label_14->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        pushButton_10 = new QPushButton(signin);
        pushButton_10->setObjectName("pushButton_10");
        pushButton_10->setGeometry(QRect(600, 380, 71, 24));
        pushButton_10->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        pushButton_11 = new QPushButton(signin);
        pushButton_11->setObjectName("pushButton_11");
        pushButton_11->setGeometry(QRect(30, 30, 75, 24));
        pushButton_11->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_15 = new QLabel(signin);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(540, 220, 101, 31));
        label_15->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        label_16 = new QLabel(signin);
        label_16->setObjectName("label_16");
        label_16->setGeometry(QRect(500, 320, 71, 16));
        label_16->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_17 = new QLabel(signin);
        label_17->setObjectName("label_17");
        label_17->setGeometry(QRect(210, 230, 271, 191));
        label_17->setPixmap(QPixmap(QString::fromUtf8("../83a8517050500a23ff0d546bea883af6.jpg")));
        label_17->setScaledContents(true);
        pushButton_12 = new QPushButton(signin);
        pushButton_12->setObjectName("pushButton_12");
        pushButton_12->setGeometry(QRect(800, 30, 75, 24));
        pushButton_12->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        lineEdit_7 = new QLineEdit(signin);
        lineEdit_7->setObjectName("lineEdit_7");
        lineEdit_7->setGeometry(QRect(500, 290, 171, 22));
        lineEdit_7->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        pushButton_13 = new QPushButton(signin);
        pushButton_13->setObjectName("pushButton_13");
        pushButton_13->setGeometry(QRect(500, 380, 71, 24));
        pushButton_13->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        lineEdit_8 = new QLineEdit(signin);
        lineEdit_8->setObjectName("lineEdit_8");
        lineEdit_8->setGeometry(QRect(500, 340, 171, 22));
        lineEdit_8->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_19 = new QLabel(signin);
        label_19->setObjectName("label_19");
        label_19->setGeometry(QRect(210, 100, 181, 91));
        label_19->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_19->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_19->setScaledContents(true);
        label_18 = new QLabel(signin);
        label_18->setObjectName("label_18");
        label_18->setGeometry(QRect(190, 80, 531, 431));
        label_18->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_18->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_18->setScaledContents(true);
        label_58 = new QLabel(signin);
        label_58->setObjectName("label_58");
        label_58->setGeometry(QRect(0, -20, 900, 600));
        label_58->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_58->setScaledContents(true);
        stackedWidget->addWidget(signin);
        label_58->raise();
        label_18->raise();
        label_17->raise();
        label_14->raise();
        pushButton_10->raise();
        pushButton_11->raise();
        label_15->raise();
        label_16->raise();
        pushButton_12->raise();
        lineEdit_7->raise();
        pushButton_13->raise();
        lineEdit_8->raise();
        label_19->raise();
        payment = new QWidget();
        payment->setObjectName("payment");
        label_35 = new QLabel(payment);
        label_35->setObjectName("label_35");
        label_35->setGeometry(QRect(240, 240, 211, 191));
        label_35->setPixmap(QPixmap(QString::fromUtf8("../top-up-credit-concept-illustration_114360-7244.jpg")));
        label_35->setScaledContents(true);
        label_36 = new QLabel(payment);
        label_36->setObjectName("label_36");
        label_36->setGeometry(QRect(500, 270, 51, 16));
        label_36->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_37 = new QLabel(payment);
        label_37->setObjectName("label_37");
        label_37->setGeometry(QRect(210, 100, 181, 91));
        label_37->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_37->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_37->setScaledContents(true);
        pushButton_21 = new QPushButton(payment);
        pushButton_21->setObjectName("pushButton_21");
        pushButton_21->setGeometry(QRect(580, 380, 91, 24));
        pushButton_21->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        label_39 = new QLabel(payment);
        label_39->setObjectName("label_39");
        label_39->setGeometry(QRect(500, 320, 71, 16));
        label_39->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        pushButton_22 = new QPushButton(payment);
        pushButton_22->setObjectName("pushButton_22");
        pushButton_22->setGeometry(QRect(30, 30, 75, 24));
        pushButton_22->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        lineEdit_11 = new QLineEdit(payment);
        lineEdit_11->setObjectName("lineEdit_11");
        lineEdit_11->setGeometry(QRect(500, 340, 171, 22));
        lineEdit_11->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_12 = new QLineEdit(payment);
        lineEdit_12->setObjectName("lineEdit_12");
        lineEdit_12->setGeometry(QRect(500, 290, 171, 22));
        lineEdit_12->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        pushButton_23 = new QPushButton(payment);
        pushButton_23->setObjectName("pushButton_23");
        pushButton_23->setGeometry(QRect(800, 30, 75, 24));
        pushButton_23->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_40 = new QLabel(payment);
        label_40->setObjectName("label_40");
        label_40->setGeometry(QRect(530, 210, 131, 31));
        label_40->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        label_38 = new QLabel(payment);
        label_38->setObjectName("label_38");
        label_38->setGeometry(QRect(190, 80, 531, 431));
        label_38->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_38->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_38->setScaledContents(true);
        label_56 = new QLabel(payment);
        label_56->setObjectName("label_56");
        label_56->setGeometry(QRect(0, -20, 900, 600));
        label_56->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_56->setScaledContents(true);
        stackedWidget->addWidget(payment);
        label_56->raise();
        label_38->raise();
        label_35->raise();
        label_36->raise();
        label_37->raise();
        pushButton_21->raise();
        label_39->raise();
        pushButton_22->raise();
        lineEdit_11->raise();
        lineEdit_12->raise();
        pushButton_23->raise();
        label_40->raise();
        busseat = new QWidget();
        busseat->setObjectName("busseat");
        label_43 = new QLabel(busseat);
        label_43->setObjectName("label_43");
        label_43->setGeometry(QRect(240, 290, 51, 16));
        label_43->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        pushButton_24 = new QPushButton(busseat);
        pushButton_24->setObjectName("pushButton_24");
        pushButton_24->setGeometry(QRect(240, 450, 111, 24));
        pushButton_24->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        logomain_2 = new QLabel(busseat);
        logomain_2->setObjectName("logomain_2");
        logomain_2->setGeometry(QRect(210, 100, 181, 91));
        logomain_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        logomain_2->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        logomain_2->setScaledContents(true);
        label_45 = new QLabel(busseat);
        label_45->setObjectName("label_45");
        label_45->setGeometry(QRect(240, 330, 81, 16));
        label_45->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_46 = new QLabel(busseat);
        label_46->setObjectName("label_46");
        label_46->setGeometry(QRect(240, 310, 71, 16));
        label_46->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        pushButton_25 = new QPushButton(busseat);
        pushButton_25->setObjectName("pushButton_25");
        pushButton_25->setGeometry(QRect(30, 30, 75, 24));
        pushButton_25->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_47 = new QLabel(busseat);
        label_47->setObjectName("label_47");
        label_47->setGeometry(QRect(470, 130, 221, 31));
        label_47->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        pushButton_26 = new QPushButton(busseat);
        pushButton_26->setObjectName("pushButton_26");
        pushButton_26->setGeometry(QRect(800, 30, 75, 24));
        pushButton_26->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        pushButton_4 = new QPushButton(busseat);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(510, 180, 41, 41));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_5 = new QPushButton(busseat);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(560, 180, 41, 41));
        pushButton_5->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_28 = new QPushButton(busseat);
        pushButton_28->setObjectName("pushButton_28");
        pushButton_28->setGeometry(QRect(610, 230, 41, 41));
        pushButton_28->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_29 = new QPushButton(busseat);
        pushButton_29->setObjectName("pushButton_29");
        pushButton_29->setGeometry(QRect(560, 230, 41, 41));
        pushButton_29->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_30 = new QPushButton(busseat);
        pushButton_30->setObjectName("pushButton_30");
        pushButton_30->setGeometry(QRect(510, 230, 41, 41));
        pushButton_30->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_31 = new QPushButton(busseat);
        pushButton_31->setObjectName("pushButton_31");
        pushButton_31->setGeometry(QRect(560, 280, 41, 41));
        pushButton_31->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_32 = new QPushButton(busseat);
        pushButton_32->setObjectName("pushButton_32");
        pushButton_32->setGeometry(QRect(510, 280, 41, 41));
        pushButton_32->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255); \n"
"font: 700 12pt \"Poppins\";\n"
""));
        pushButton_33 = new QPushButton(busseat);
        pushButton_33->setObjectName("pushButton_33");
        pushButton_33->setGeometry(QRect(610, 280, 41, 41));
        pushButton_33->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_27 = new QPushButton(busseat);
        pushButton_27->setObjectName("pushButton_27");
        pushButton_27->setGeometry(QRect(610, 180, 41, 41));
        pushButton_27->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_34 = new QPushButton(busseat);
        pushButton_34->setObjectName("pushButton_34");
        pushButton_34->setGeometry(QRect(560, 380, 41, 41));
        pushButton_34->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_35 = new QPushButton(busseat);
        pushButton_35->setObjectName("pushButton_35");
        pushButton_35->setGeometry(QRect(510, 380, 41, 41));
        pushButton_35->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_36 = new QPushButton(busseat);
        pushButton_36->setObjectName("pushButton_36");
        pushButton_36->setGeometry(QRect(610, 380, 41, 41));
        pushButton_36->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_37 = new QPushButton(busseat);
        pushButton_37->setObjectName("pushButton_37");
        pushButton_37->setGeometry(QRect(560, 430, 41, 41));
        pushButton_37->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_38 = new QPushButton(busseat);
        pushButton_38->setObjectName("pushButton_38");
        pushButton_38->setGeometry(QRect(510, 430, 41, 41));
        pushButton_38->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_39 = new QPushButton(busseat);
        pushButton_39->setObjectName("pushButton_39");
        pushButton_39->setGeometry(QRect(610, 430, 41, 41));
        pushButton_39->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_40 = new QPushButton(busseat);
        pushButton_40->setObjectName("pushButton_40");
        pushButton_40->setGeometry(QRect(560, 330, 41, 41));
        pushButton_40->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_41 = new QPushButton(busseat);
        pushButton_41->setObjectName("pushButton_41");
        pushButton_41->setGeometry(QRect(510, 330, 41, 41));
        pushButton_41->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        pushButton_42 = new QPushButton(busseat);
        pushButton_42->setObjectName("pushButton_42");
        pushButton_42->setGeometry(QRect(610, 330, 41, 41));
        pushButton_42->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 12pt \"Poppins\";"));
        label_12 = new QLabel(busseat);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(230, 200, 131, 41));
        label_12->setPixmap(QPixmap(QString::fromUtf8("../green-line-logo.jpg")));
        label_12->setScaledContents(true);
        label_48 = new QLabel(busseat);
        label_48->setObjectName("label_48");
        label_48->setGeometry(QRect(240, 250, 101, 16));
        label_48->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        textBrowser_3 = new QTextBrowser(busseat);
        textBrowser_3->setObjectName("textBrowser_3");
        textBrowser_3->setGeometry(QRect(240, 350, 201, 81));
        textBrowser_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(0, 0, 0);"));
        label_49 = new QLabel(busseat);
        label_49->setObjectName("label_49");
        label_49->setGeometry(QRect(240, 270, 151, 16));
        label_49->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_42 = new QLabel(busseat);
        label_42->setObjectName("label_42");
        label_42->setGeometry(QRect(190, 80, 531, 431));
        label_42->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_42->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_42->setScaledContents(true);
        label_53 = new QLabel(busseat);
        label_53->setObjectName("label_53");
        label_53->setGeometry(QRect(0, -20, 900, 600));
        label_53->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_53->setScaledContents(true);
        label_336 = new QLabel(busseat);
        label_336->setObjectName("label_336");
        label_336->setGeometry(QRect(280, 290, 81, 16));
        label_336->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));
        label_337 = new QLabel(busseat);
        label_337->setObjectName("label_337");
        label_337->setGeometry(QRect(280, 310, 81, 16));
        label_337->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        Time1 = new QLabel(busseat);
        Time1->setObjectName("Time1");
        Time1->setGeometry(QRect(320, 330, 49, 16));
        Time1->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        stackedWidget->addWidget(busseat);
        label_53->raise();
        label_42->raise();
        label_43->raise();
        pushButton_24->raise();
        logomain_2->raise();
        label_45->raise();
        label_46->raise();
        pushButton_25->raise();
        label_47->raise();
        pushButton_26->raise();
        pushButton_4->raise();
        pushButton_5->raise();
        pushButton_28->raise();
        pushButton_29->raise();
        pushButton_30->raise();
        pushButton_31->raise();
        pushButton_32->raise();
        pushButton_33->raise();
        pushButton_27->raise();
        pushButton_34->raise();
        pushButton_35->raise();
        pushButton_36->raise();
        pushButton_37->raise();
        pushButton_38->raise();
        pushButton_39->raise();
        pushButton_40->raise();
        pushButton_41->raise();
        pushButton_42->raise();
        label_12->raise();
        label_48->raise();
        textBrowser_3->raise();
        label_49->raise();
        label_336->raise();
        label_337->raise();
        Time1->raise();
        invoice = new QWidget();
        invoice->setObjectName("invoice");
        pushButton_85 = new QPushButton(invoice);
        pushButton_85->setObjectName("pushButton_85");
        pushButton_85->setGeometry(QRect(30, 30, 75, 24));
        pushButton_85->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        logomain = new QLabel(invoice);
        logomain->setObjectName("logomain");
        logomain->setGeometry(QRect(210, 110, 181, 91));
        logomain->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        logomain->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        logomain->setScaledContents(true);
        label_96 = new QLabel(invoice);
        label_96->setObjectName("label_96");
        label_96->setGeometry(QRect(230, 260, 221, 181));
        label_96->setPixmap(QPixmap(QString::fromUtf8("../7f2275b1-c597-4598-9a82-494c1e22e922.png")));
        label_96->setScaledContents(true);
        label_97 = new QLabel(invoice);
        label_97->setObjectName("label_97");
        label_97->setGeometry(QRect(480, 260, 51, 16));
        label_97->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        pushButton_86 = new QPushButton(invoice);
        pushButton_86->setObjectName("pushButton_86");
        pushButton_86->setGeometry(QRect(800, 30, 75, 24));
        pushButton_86->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        pushButton_87 = new QPushButton(invoice);
        pushButton_87->setObjectName("pushButton_87");
        pushButton_87->setGeometry(QRect(600, 460, 91, 24));
        pushButton_87->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        label_98 = new QLabel(invoice);
        label_98->setObjectName("label_98");
        label_98->setGeometry(QRect(480, 290, 71, 16));
        label_98->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_100 = new QLabel(invoice);
        label_100->setObjectName("label_100");
        label_100->setGeometry(QRect(480, 140, 211, 31));
        label_100->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        label_101 = new QLabel(invoice);
        label_101->setObjectName("label_101");
        label_101->setGeometry(QRect(480, 230, 51, 16));
        label_101->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_102 = new QLabel(invoice);
        label_102->setObjectName("label_102");
        label_102->setGeometry(QRect(480, 320, 71, 16));
        label_102->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_103 = new QLabel(invoice);
        label_103->setObjectName("label_103");
        label_103->setGeometry(QRect(480, 350, 71, 16));
        label_103->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_104 = new QLabel(invoice);
        label_104->setObjectName("label_104");
        label_104->setGeometry(QRect(480, 380, 81, 16));
        label_104->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_13 = new QLabel(invoice);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(540, 230, 101, 16));
        label_13->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_44 = new QLabel(invoice);
        label_44->setObjectName("label_44");
        label_44->setGeometry(QRect(230, 430, 221, 21));
        label_44->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lb_inv_contact = new QLabel(invoice);
        lb_inv_contact->setObjectName("lb_inv_contact");
        lb_inv_contact->setGeometry(QRect(550, 260, 101, 16));
        lb_inv_contact->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lb_inv_Email = new QLabel(invoice);
        lb_inv_Email->setObjectName("lb_inv_Email");
        lb_inv_Email->setGeometry(QRect(540, 290, 101, 16));
        lb_inv_Email->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lb_inv_Paid = new QLabel(invoice);
        lb_inv_Paid->setObjectName("lb_inv_Paid");
        lb_inv_Paid->setGeometry(QRect(530, 320, 101, 16));
        lb_inv_Paid->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lb_inv_Seats = new QLabel(invoice);
        lb_inv_Seats->setObjectName("lb_inv_Seats");
        lb_inv_Seats->setGeometry(QRect(540, 350, 101, 16));
        lb_inv_Seats->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lb_inv_Date = new QLabel(invoice);
        lb_inv_Date->setObjectName("lb_inv_Date");
        lb_inv_Date->setGeometry(QRect(570, 380, 101, 16));
        lb_inv_Date->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_51 = new QLabel(invoice);
        label_51->setObjectName("label_51");
        label_51->setGeometry(QRect(190, 80, 531, 431));
        label_51->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_51->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_51->setScaledContents(true);
        label_55 = new QLabel(invoice);
        label_55->setObjectName("label_55");
        label_55->setGeometry(QRect(0, -20, 900, 600));
        label_55->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_55->setScaledContents(true);
        label_332 = new QLabel(invoice);
        label_332->setObjectName("label_332");
        label_332->setGeometry(QRect(480, 400, 49, 16));
        label_332->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_333 = new QLabel(invoice);
        label_333->setObjectName("label_333");
        label_333->setGeometry(QRect(480, 420, 49, 16));
        label_333->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_334 = new QLabel(invoice);
        label_334->setObjectName("label_334");
        label_334->setGeometry(QRect(540, 400, 101, 16));
        label_334->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_335 = new QLabel(invoice);
        label_335->setObjectName("label_335");
        label_335->setGeometry(QRect(540, 420, 101, 16));
        label_335->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        stackedWidget->addWidget(invoice);
        label_55->raise();
        label_51->raise();
        pushButton_85->raise();
        logomain->raise();
        label_96->raise();
        label_97->raise();
        pushButton_86->raise();
        pushButton_87->raise();
        label_98->raise();
        label_100->raise();
        label_101->raise();
        label_102->raise();
        label_103->raise();
        label_104->raise();
        label_13->raise();
        label_44->raise();
        lb_inv_contact->raise();
        lb_inv_Email->raise();
        lb_inv_Paid->raise();
        lb_inv_Seats->raise();
        lb_inv_Date->raise();
        label_332->raise();
        label_333->raise();
        label_334->raise();
        label_335->raise();
        refundapply = new QWidget();
        refundapply->setObjectName("refundapply");
        label_60 = new QLabel(refundapply);
        label_60->setObjectName("label_60");
        label_60->setGeometry(QRect(210, 100, 181, 91));
        label_60->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_60->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_60->setScaledContents(true);
        label_61 = new QLabel(refundapply);
        label_61->setObjectName("label_61");
        label_61->setGeometry(QRect(460, 140, 221, 31));
        label_61->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        label_63 = new QLabel(refundapply);
        label_63->setObjectName("label_63");
        label_63->setGeometry(QRect(480, 240, 91, 16));
        label_63->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_64 = new QLabel(refundapply);
        label_64->setObjectName("label_64");
        label_64->setGeometry(QRect(0, -20, 900, 600));
        label_64->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_64->setScaledContents(true);
        label_65 = new QLabel(refundapply);
        label_65->setObjectName("label_65");
        label_65->setGeometry(QRect(190, 80, 531, 431));
        label_65->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_65->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_65->setScaledContents(true);
        pushButton_43 = new QPushButton(refundapply);
        pushButton_43->setObjectName("pushButton_43");
        pushButton_43->setGeometry(QRect(580, 400, 71, 24));
        pushButton_43->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        lineEdit_13 = new QLineEdit(refundapply);
        lineEdit_13->setObjectName("lineEdit_13");
        lineEdit_13->setGeometry(QRect(480, 360, 171, 22));
        lineEdit_13->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_66 = new QLabel(refundapply);
        label_66->setObjectName("label_66");
        label_66->setGeometry(QRect(210, 250, 251, 161));
        label_66->setPixmap(QPixmap(QString::fromUtf8("../cash-back-concept-tiny-people-refund-money-reward-program_25441151.jpg")));
        label_66->setScaledContents(true);
        pushButton_44 = new QPushButton(refundapply);
        pushButton_44->setObjectName("pushButton_44");
        pushButton_44->setGeometry(QRect(30, 30, 75, 24));
        pushButton_44->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        pushButton_45 = new QPushButton(refundapply);
        pushButton_45->setObjectName("pushButton_45");
        pushButton_45->setGeometry(QRect(800, 30, 75, 24));
        pushButton_45->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_67 = new QLabel(refundapply);
        label_67->setObjectName("label_67");
        label_67->setGeometry(QRect(480, 290, 91, 16));
        label_67->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_68 = new QLabel(refundapply);
        label_68->setObjectName("label_68");
        label_68->setGeometry(QRect(480, 340, 171, 16));
        label_68->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        lineEdit_14 = new QLineEdit(refundapply);
        lineEdit_14->setObjectName("lineEdit_14");
        lineEdit_14->setGeometry(QRect(480, 310, 171, 22));
        lineEdit_14->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_15 = new QLineEdit(refundapply);
        lineEdit_15->setObjectName("lineEdit_15");
        lineEdit_15->setGeometry(QRect(480, 260, 171, 22));
        lineEdit_15->setStyleSheet(QString::fromUtf8("background-color: rgb(255,255, 255);\n"
"color: rgb(0, 0, 0);"));
        stackedWidget->addWidget(refundapply);
        label_64->raise();
        label_65->raise();
        label_60->raise();
        label_61->raise();
        label_63->raise();
        pushButton_43->raise();
        lineEdit_13->raise();
        label_66->raise();
        pushButton_44->raise();
        pushButton_45->raise();
        label_67->raise();
        label_68->raise();
        lineEdit_14->raise();
        lineEdit_15->raise();
        admin = new QWidget();
        admin->setObjectName("admin");
        label_41 = new QLabel(admin);
        label_41->setObjectName("label_41");
        label_41->setGeometry(QRect(190, 80, 531, 431));
        label_41->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_41->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_41->setScaledContents(true);
        label_70 = new QLabel(admin);
        label_70->setObjectName("label_70");
        label_70->setGeometry(QRect(210, 100, 181, 91));
        label_70->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_70->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_70->setScaledContents(true);
        label_71 = new QLabel(admin);
        label_71->setObjectName("label_71");
        label_71->setGeometry(QRect(420, 340, 131, 31));
        label_71->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(0, 0, 0);"));
        pushButton_46 = new QPushButton(admin);
        pushButton_46->setObjectName("pushButton_46");
        pushButton_46->setGeometry(QRect(30, 30, 75, 24));
        pushButton_46->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_72 = new QLabel(admin);
        label_72->setObjectName("label_72");
        label_72->setGeometry(QRect(380, 200, 161, 151));
        label_72->setPixmap(QPixmap(QString::fromUtf8("../experience-people-value-color-icon-vector-35842699.jpg")));
        label_72->setScaledContents(true);
        pushButton_47 = new QPushButton(admin);
        pushButton_47->setObjectName("pushButton_47");
        pushButton_47->setGeometry(QRect(800, 30, 75, 24));
        pushButton_47->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_74 = new QLabel(admin);
        label_74->setObjectName("label_74");
        label_74->setGeometry(QRect(0, -20, 900, 600));
        label_74->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_74->setScaledContents(true);
        pushButton_48 = new QPushButton(admin);
        pushButton_48->setObjectName("pushButton_48");
        pushButton_48->setGeometry(QRect(340, 390, 111, 31));
        pushButton_48->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        pushButton_49 = new QPushButton(admin);
        pushButton_49->setObjectName("pushButton_49");
        pushButton_49->setGeometry(QRect(470, 390, 111, 31));
        pushButton_49->setStyleSheet(QString::fromUtf8("background-color: rgb(6, 156, 140);\n"
"font: 700 9pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));
        stackedWidget->addWidget(admin);
        label_74->raise();
        label_41->raise();
        label_70->raise();
        pushButton_46->raise();
        label_72->raise();
        pushButton_47->raise();
        pushButton_48->raise();
        label_71->raise();
        pushButton_49->raise();
        Seatcontrol = new QWidget();
        Seatcontrol->setObjectName("Seatcontrol");
        label_69 = new QLabel(Seatcontrol);
        label_69->setObjectName("label_69");
        label_69->setGeometry(QRect(210, 100, 181, 91));
        label_69->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_69->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_69->setScaledContents(true);
        pushButton_50 = new QPushButton(Seatcontrol);
        pushButton_50->setObjectName("pushButton_50");
        pushButton_50->setGeometry(QRect(800, 30, 75, 24));
        pushButton_50->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        pushButton_51 = new QPushButton(Seatcontrol);
        pushButton_51->setObjectName("pushButton_51");
        pushButton_51->setGeometry(QRect(30, 30, 75, 24));
        pushButton_51->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_75 = new QLabel(Seatcontrol);
        label_75->setObjectName("label_75");
        label_75->setGeometry(QRect(190, 80, 531, 431));
        label_75->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_75->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_75->setScaledContents(true);
        label_76 = new QLabel(Seatcontrol);
        label_76->setObjectName("label_76");
        label_76->setGeometry(QRect(0, -20, 900, 600));
        label_76->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_76->setScaledContents(true);
        label_77 = new QLabel(Seatcontrol);
        label_77->setObjectName("label_77");
        label_77->setGeometry(QRect(530, 160, 151, 31));
        label_77->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        label_78 = new QLabel(Seatcontrol);
        label_78->setObjectName("label_78");
        label_78->setGeometry(QRect(580, 120, 101, 31));
        label_78->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 22pt \"Poppins\";\n"
"color: rgb(0, 0, 0);"));
        label_73 = new QLabel(Seatcontrol);
        label_73->setObjectName("label_73");
        label_73->setGeometry(QRect(530, 110, 41, 41));
        label_73->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_73->setPixmap(QPixmap(QString::fromUtf8("../2206248.png")));
        label_73->setScaledContents(true);
        tableView = new QTableView(Seatcontrol);
        tableView->setObjectName("tableView");
        tableView->setGeometry(QRect(330, 200, 251, 251));
        tableView->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_55 = new QPushButton(Seatcontrol);
        pushButton_55->setObjectName("pushButton_55");
        pushButton_55->setGeometry(QRect(420, 470, 80, 24));
        stackedWidget->addWidget(Seatcontrol);
        label_76->raise();
        label_75->raise();
        label_69->raise();
        pushButton_50->raise();
        pushButton_51->raise();
        label_77->raise();
        label_78->raise();
        label_73->raise();
        tableView->raise();
        pushButton_55->raise();
        Refundcontrol = new QWidget();
        Refundcontrol->setObjectName("Refundcontrol");
        label_79 = new QLabel(Refundcontrol);
        label_79->setObjectName("label_79");
        label_79->setGeometry(QRect(210, 100, 181, 91));
        label_79->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_79->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_79->setScaledContents(true);
        pushButton_52 = new QPushButton(Refundcontrol);
        pushButton_52->setObjectName("pushButton_52");
        pushButton_52->setGeometry(QRect(800, 30, 75, 24));
        pushButton_52->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_80 = new QLabel(Refundcontrol);
        label_80->setObjectName("label_80");
        label_80->setGeometry(QRect(0, -20, 900, 600));
        label_80->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_80->setScaledContents(true);
        label_81 = new QLabel(Refundcontrol);
        label_81->setObjectName("label_81");
        label_81->setGeometry(QRect(580, 120, 101, 31));
        label_81->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 22pt \"Poppins\";\n"
"color: rgb(0, 0, 0);"));
        pushButton_53 = new QPushButton(Refundcontrol);
        pushButton_53->setObjectName("pushButton_53");
        pushButton_53->setGeometry(QRect(30, 30, 75, 24));
        pushButton_53->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_82 = new QLabel(Refundcontrol);
        label_82->setObjectName("label_82");
        label_82->setGeometry(QRect(500, 160, 191, 31));
        label_82->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        label_83 = new QLabel(Refundcontrol);
        label_83->setObjectName("label_83");
        label_83->setGeometry(QRect(190, 80, 531, 431));
        label_83->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_83->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_83->setScaledContents(true);
        label_84 = new QLabel(Refundcontrol);
        label_84->setObjectName("label_84");
        label_84->setGeometry(QRect(530, 110, 41, 41));
        label_84->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_84->setPixmap(QPixmap(QString::fromUtf8("../2206248.png")));
        label_84->setScaledContents(true);
        tableView_2 = new QTableView(Refundcontrol);
        tableView_2->setObjectName("tableView_2");
        tableView_2->setGeometry(QRect(330, 220, 256, 192));
        tableView_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        pushButton_63 = new QPushButton(Refundcontrol);
        pushButton_63->setObjectName("pushButton_63");
        pushButton_63->setGeometry(QRect(420, 430, 91, 24));
        stackedWidget->addWidget(Refundcontrol);
        pushButton_52->raise();
        label_80->raise();
        pushButton_53->raise();
        label_83->raise();
        label_84->raise();
        label_79->raise();
        label_81->raise();
        label_82->raise();
        tableView_2->raise();
        pushButton_63->raise();
        aboutus = new QWidget();
        aboutus->setObjectName("aboutus");
        pushButton_15 = new QPushButton(aboutus);
        pushButton_15->setObjectName("pushButton_15");
        pushButton_15->setGeometry(QRect(30, 30, 75, 24));
        pushButton_15->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_21 = new QLabel(aboutus);
        label_21->setObjectName("label_21");
        label_21->setGeometry(QRect(560, 180, 131, 31));
        label_21->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        label_23 = new QLabel(aboutus);
        label_23->setObjectName("label_23");
        label_23->setGeometry(QRect(600, 100, 91, 81));
        label_23->setPixmap(QPixmap(QString::fromUtf8("../startttt.jpg")));
        label_23->setScaledContents(true);
        pushButton_16 = new QPushButton(aboutus);
        pushButton_16->setObjectName("pushButton_16");
        pushButton_16->setGeometry(QRect(800, 30, 75, 24));
        pushButton_16->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        logomain_3 = new QLabel(aboutus);
        logomain_3->setObjectName("logomain_3");
        logomain_3->setGeometry(QRect(210, 100, 181, 91));
        logomain_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        logomain_3->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        logomain_3->setScaledContents(true);
        textBrowser = new QTextBrowser(aboutus);
        textBrowser->setObjectName("textBrowser");
        textBrowser->setGeometry(QRect(230, 220, 451, 251));
        textBrowser->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 700 8pt \"Segoe UI\";"));
        label_24 = new QLabel(aboutus);
        label_24->setObjectName("label_24");
        label_24->setGeometry(QRect(190, 80, 531, 431));
        label_24->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_24->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_24->setScaledContents(true);
        label_52 = new QLabel(aboutus);
        label_52->setObjectName("label_52");
        label_52->setGeometry(QRect(0, -20, 900, 600));
        label_52->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_52->setScaledContents(true);
        stackedWidget->addWidget(aboutus);
        label_52->raise();
        label_24->raise();
        pushButton_15->raise();
        label_21->raise();
        label_23->raise();
        pushButton_16->raise();
        logomain_3->raise();
        textBrowser->raise();
        userdashboard = new QWidget();
        userdashboard->setObjectName("userdashboard");
        pushButton_59 = new QPushButton(userdashboard);
        pushButton_59->setObjectName("pushButton_59");
        pushButton_59->setGeometry(QRect(30, 30, 75, 24));
        pushButton_59->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_91 = new QLabel(userdashboard);
        label_91->setObjectName("label_91");
        label_91->setGeometry(QRect(190, 80, 531, 431));
        label_91->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_91->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_91->setScaledContents(true);
        label_92 = new QLabel(userdashboard);
        label_92->setObjectName("label_92");
        label_92->setGeometry(QRect(210, 100, 181, 91));
        label_92->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_92->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        label_92->setScaledContents(true);
        pushButton_60 = new QPushButton(userdashboard);
        pushButton_60->setObjectName("pushButton_60");
        pushButton_60->setGeometry(QRect(800, 30, 75, 24));
        pushButton_60->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        label_93 = new QLabel(userdashboard);
        label_93->setObjectName("label_93");
        label_93->setGeometry(QRect(0, -20, 900, 600));
        label_93->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_93->setScaledContents(true);
        label_25 = new QLabel(userdashboard);
        label_25->setObjectName("label_25");
        label_25->setGeometry(QRect(250, 260, 41, 16));
        label_25->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 9pt \"Poppins\";\n"
"color: rgb(0, 0, 0);"));
        label_30 = new QLabel(userdashboard);
        label_30->setObjectName("label_30");
        label_30->setGeometry(QRect(250, 290, 41, 16));
        label_30->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 9pt \"Poppins\";\n"
"color: rgb(0, 0, 0);"));
        label_90 = new QLabel(userdashboard);
        label_90->setObjectName("label_90");
        label_90->setGeometry(QRect(250, 350, 91, 16));
        label_90->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 9pt \"Poppins\";\n"
"color: rgb(0, 0, 0);"));
        label_94 = new QLabel(userdashboard);
        label_94->setObjectName("label_94");
        label_94->setGeometry(QRect(250, 320, 51, 16));
        label_94->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 9pt \"Poppins\";\n"
"color: rgb(0, 0, 0);"));
        pushButton_61 = new QPushButton(userdashboard);
        pushButton_61->setObjectName("pushButton_61");
        pushButton_61->setGeometry(QRect(570, 451, 111, 20));
        pushButton_61->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"background-color: rgb(0, 114, 127);\n"
"color: rgb(255, 255, 255);\n"
"\n"
""));
        label_95 = new QLabel(userdashboard);
        label_95->setObjectName("label_95");
        label_95->setGeometry(QRect(480, 200, 211, 191));
        label_95->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_95->setPixmap(QPixmap(QString::fromUtf8("../userimage.jpg")));
        label_95->setScaledContents(true);
        label_99 = new QLabel(userdashboard);
        label_99->setObjectName("label_99");
        label_99->setGeometry(QRect(250, 220, 181, 20));
        label_99->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 15pt \"Poppins\";\n"
"color: rgb(3, 115, 125);\n"
""));
        pushButton_62 = new QPushButton(userdashboard);
        pushButton_62->setObjectName("pushButton_62");
        pushButton_62->setGeometry(QRect(240, 450, 101, 21));
        pushButton_62->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe UI\";\n"
"background-color: rgb(0, 114, 127);\n"
"color: rgb(255, 255, 255);\n"
"\n"
""));
        label_62 = new QLabel(userdashboard);
        label_62->setObjectName("label_62");
        label_62->setGeometry(QRect(290, 260, 111, 16));
        label_85 = new QLabel(userdashboard);
        label_85->setObjectName("label_85");
        label_85->setGeometry(QRect(290, 290, 111, 16));
        label_105 = new QLabel(userdashboard);
        label_105->setObjectName("label_105");
        label_105->setGeometry(QRect(340, 350, 111, 16));
        label_106 = new QLabel(userdashboard);
        label_106->setObjectName("label_106");
        label_106->setGeometry(QRect(300, 320, 111, 16));
        stackedWidget->addWidget(userdashboard);
        label_93->raise();
        pushButton_59->raise();
        label_91->raise();
        label_92->raise();
        pushButton_60->raise();
        pushButton_61->raise();
        label_95->raise();
        label_94->raise();
        label_25->raise();
        label_30->raise();
        label_90->raise();
        label_99->raise();
        pushButton_62->raise();
        label_62->raise();
        label_85->raise();
        label_105->raise();
        label_106->raise();
        invoiceprint = new QWidget();
        invoiceprint->setObjectName("invoiceprint");
        label_319 = new QLabel(invoiceprint);
        label_319->setObjectName("label_319");
        label_319->setGeometry(QRect(480, 290, 71, 16));
        label_319->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_320 = new QLabel(invoiceprint);
        label_320->setObjectName("label_320");
        label_320->setGeometry(QRect(190, 80, 531, 431));
        label_320->setStyleSheet(QString::fromUtf8("background-color: rgba(0, 0, 0, 0);"));
        label_320->setPixmap(QPixmap(QString::fromUtf8("../proqw1.png")));
        label_320->setScaledContents(true);
        label_321 = new QLabel(invoiceprint);
        label_321->setObjectName("label_321");
        label_321->setGeometry(QRect(540, 230, 101, 16));
        label_321->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_322 = new QLabel(invoiceprint);
        label_322->setObjectName("label_322");
        label_322->setGeometry(QRect(480, 350, 71, 16));
        label_322->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_323 = new QLabel(invoiceprint);
        label_323->setObjectName("label_323");
        label_323->setGeometry(QRect(230, 260, 221, 181));
        label_323->setPixmap(QPixmap(QString::fromUtf8("../7f2275b1-c597-4598-9a82-494c1e22e922.png")));
        label_323->setScaledContents(true);
        label_324 = new QLabel(invoiceprint);
        label_324->setObjectName("label_324");
        label_324->setGeometry(QRect(230, 430, 221, 21));
        label_324->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_325 = new QLabel(invoiceprint);
        label_325->setObjectName("label_325");
        label_325->setGeometry(QRect(480, 140, 211, 31));
        label_325->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Poppins\";\n"
"color: rgb(6, 156, 140);"));
        label_326 = new QLabel(invoiceprint);
        label_326->setObjectName("label_326");
        label_326->setGeometry(QRect(0, -20, 900, 600));
        label_326->setPixmap(QPixmap(QString::fromUtf8("../backgrndofdurutto.jpg")));
        label_326->setScaledContents(true);
        lb_inv_Date_4 = new QLabel(invoiceprint);
        lb_inv_Date_4->setObjectName("lb_inv_Date_4");
        lb_inv_Date_4->setGeometry(QRect(570, 380, 101, 16));
        lb_inv_Date_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        logomain_13 = new QLabel(invoiceprint);
        logomain_13->setObjectName("logomain_13");
        logomain_13->setGeometry(QRect(210, 120, 181, 91));
        logomain_13->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        logomain_13->setPixmap(QPixmap(QString::fromUtf8("../durutto logo.png")));
        logomain_13->setScaledContents(true);
        label_327 = new QLabel(invoiceprint);
        label_327->setObjectName("label_327");
        label_327->setGeometry(QRect(480, 380, 81, 16));
        label_327->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        lb_inv_Email_4 = new QLabel(invoiceprint);
        lb_inv_Email_4->setObjectName("lb_inv_Email_4");
        lb_inv_Email_4->setGeometry(QRect(540, 290, 101, 16));
        lb_inv_Email_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lb_inv_contact_4 = new QLabel(invoiceprint);
        lb_inv_contact_4->setObjectName("lb_inv_contact_4");
        lb_inv_contact_4->setGeometry(QRect(550, 260, 101, 16));
        lb_inv_contact_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lb_inv_Paid_4 = new QLabel(invoiceprint);
        lb_inv_Paid_4->setObjectName("lb_inv_Paid_4");
        lb_inv_Paid_4->setGeometry(QRect(530, 320, 101, 16));
        lb_inv_Paid_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_328 = new QLabel(invoiceprint);
        label_328->setObjectName("label_328");
        label_328->setGeometry(QRect(480, 260, 51, 16));
        label_328->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        label_329 = new QLabel(invoiceprint);
        label_329->setObjectName("label_329");
        label_329->setGeometry(QRect(480, 320, 71, 16));
        label_329->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        lb_inv_Seats_4 = new QLabel(invoiceprint);
        lb_inv_Seats_4->setObjectName("lb_inv_Seats_4");
        lb_inv_Seats_4->setGeometry(QRect(540, 350, 101, 16));
        lb_inv_Seats_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_330 = new QLabel(invoiceprint);
        label_330->setObjectName("label_330");
        label_330->setGeometry(QRect(480, 230, 51, 16));
        label_330->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"font: 500 9pt \"Poppins\";"));
        stackedWidget->addWidget(invoiceprint);
        label_326->raise();
        label_320->raise();
        label_321->raise();
        label_322->raise();
        label_323->raise();
        label_324->raise();
        label_325->raise();
        lb_inv_Date_4->raise();
        logomain_13->raise();
        label_327->raise();
        lb_inv_Email_4->raise();
        lb_inv_contact_4->raise();
        lb_inv_Paid_4->raise();
        label_328->raise();
        label_329->raise();
        lb_inv_Seats_4->raise();
        label_330->raise();
        label_319->raise();
        page = new QWidget();
        page->setObjectName("page");
        comboBox = new QComboBox(page);
        comboBox->setObjectName("comboBox");
        comboBox->setGeometry(QRect(370, 250, 201, 24));
        label_331 = new QLabel(page);
        label_331->setObjectName("label_331");
        label_331->setGeometry(QRect(370, 290, 151, 16));
        stackedWidget->addWidget(page);
        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label_2->setText(QString());
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "About Us", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Refund Policy", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "Buy a Ticket", nullptr));
        label->setText(QString());
        label_3->setText(QString());
        label_50->setText(QString());
        pushButton_54->setText(QCoreApplication::translate("MainWindow", "Admin", nullptr));
        pushButton_56->setText(QCoreApplication::translate("MainWindow", "Developers", nullptr));
        label_86->setText(QString());
        label_87->setText(QString());
        pushButton_57->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        pushButton_58->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        label_88->setText(QString());
        label_89->setText(QString());
        pushButton_17->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        label_26->setText(QString());
        textBrowser_2->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:8pt; font-weight:700; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">At Durutto, we prioritize your travel satisfaction. If you need to cancel your reservation, you can receive a refund if the cancellation is made at least 24 hours before your scheduled departure. However, cancellations within 24 hours of departure and no-shows are non-refundable. To request a refund, simply reach out to our customer support at [Contact Email], provide your booking de"
                        "tails, and the refund process will be initiated, usually completed within [X] business days upon approval. Please note that in cases of service disruptions or changes, we'll ensure suitable alternatives or refunds as necessary. Our goal is to provide you with a smooth and convenient bus reservation experience, and we're here to assist you with any refund-related inquiries.</p></body></html>", nullptr));
        label_27->setText(QString());
        label_22->setText(QCoreApplication::translate("MainWindow", "REFUND POLICY", nullptr));
        pushButton_18->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        label_28->setText(QString());
        label_57->setText(QString());
        label_20->setText(QString());
        label_29->setText(QCoreApplication::translate("MainWindow", "From", nullptr));
        logomain_4->setText(QString());
        pushButton_14->setText(QCoreApplication::translate("MainWindow", "Check Availability", nullptr));
        label_32->setText(QCoreApplication::translate("MainWindow", "To", nullptr));
        pushButton_19->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        pushButton_20->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        label_33->setText(QCoreApplication::translate("MainWindow", "PLAN YOUR TOUR", nullptr));
        label_34->setText(QCoreApplication::translate("MainWindow", "Date & Time", nullptr));
        label_31->setText(QString());
        label_54->setText(QString());
        label_4->setText(QString());
        label_6->setText(QString());
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "SIGN UP", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Name", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "Email", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "Phone", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "Password", nullptr));
        pushButton_7->setText(QCoreApplication::translate("MainWindow", "Sign Up", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWindow", "Log In", nullptr));
        pushButton_9->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        label_5->setText(QString());
        label_59->setText(QString());
        label_14->setText(QCoreApplication::translate("MainWindow", "Email", nullptr));
        pushButton_10->setText(QCoreApplication::translate("MainWindow", "Log In", nullptr));
        pushButton_11->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "SIGN IN", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "Password", nullptr));
        label_17->setText(QString());
        pushButton_12->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        pushButton_13->setText(QCoreApplication::translate("MainWindow", "Sign Up", nullptr));
        label_19->setText(QString());
        label_18->setText(QString());
        label_58->setText(QString());
        label_35->setText(QString());
        label_36->setText(QCoreApplication::translate("MainWindow", "Number", nullptr));
        label_37->setText(QString());
        pushButton_21->setText(QCoreApplication::translate("MainWindow", "SUBMIT", nullptr));
        label_39->setText(QCoreApplication::translate("MainWindow", "TRXID", nullptr));
        pushButton_22->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        pushButton_23->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        label_40->setText(QCoreApplication::translate("MainWindow", "Payment ", nullptr));
        label_38->setText(QString());
        label_56->setText(QString());
        label_43->setText(QCoreApplication::translate("MainWindow", "From:", nullptr));
        pushButton_24->setText(QCoreApplication::translate("MainWindow", "Confirm Seats", nullptr));
        logomain_2->setText(QString());
        label_45->setText(QCoreApplication::translate("MainWindow", "Date & Time:", nullptr));
        label_46->setText(QCoreApplication::translate("MainWindow", "To:", nullptr));
        pushButton_25->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        label_47->setText(QCoreApplication::translate("MainWindow", "Select Your Seats", nullptr));
        pushButton_26->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        pushButton_4->setText(QCoreApplication::translate("MainWindow", "A1", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "A2", nullptr));
        pushButton_28->setText(QCoreApplication::translate("MainWindow", "B3", nullptr));
        pushButton_29->setText(QCoreApplication::translate("MainWindow", "B2", nullptr));
        pushButton_30->setText(QCoreApplication::translate("MainWindow", "B1", nullptr));
        pushButton_31->setText(QCoreApplication::translate("MainWindow", "C2", nullptr));
        pushButton_32->setText(QCoreApplication::translate("MainWindow", "C1", nullptr));
        pushButton_33->setText(QCoreApplication::translate("MainWindow", "C3", nullptr));
        pushButton_27->setText(QCoreApplication::translate("MainWindow", "A3", nullptr));
        pushButton_34->setText(QCoreApplication::translate("MainWindow", "E2", nullptr));
        pushButton_35->setText(QCoreApplication::translate("MainWindow", "E1", nullptr));
        pushButton_36->setText(QCoreApplication::translate("MainWindow", "E3", nullptr));
        pushButton_37->setText(QCoreApplication::translate("MainWindow", "F2", nullptr));
        pushButton_38->setText(QCoreApplication::translate("MainWindow", "F1", nullptr));
        pushButton_39->setText(QCoreApplication::translate("MainWindow", "F3", nullptr));
        pushButton_40->setText(QCoreApplication::translate("MainWindow", "D2", nullptr));
        pushButton_41->setText(QCoreApplication::translate("MainWindow", "D1", nullptr));
        pushButton_42->setText(QCoreApplication::translate("MainWindow", "D3", nullptr));
        label_12->setText(QString());
        label_48->setText(QCoreApplication::translate("MainWindow", "Class: Business", nullptr));
        textBrowser_3->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:10pt; font-weight:700;\">Payment Method:</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">1.Pay by Nagad/Bkash/Rocket</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2. Payment Number: 01822823007</p>\n"
"<p sty"
                        "le=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">3. Collect TRXID and Number</p></body></html>", nullptr));
        label_49->setText(QCoreApplication::translate("MainWindow", "Cost Per Seat: 2100 TAKA", nullptr));
        label_42->setText(QString());
        label_53->setText(QString());
        label_336->setText(QString());
        label_337->setText(QString());
        Time1->setText(QString());
        pushButton_85->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        logomain->setText(QString());
        label_96->setText(QString());
        label_97->setText(QCoreApplication::translate("MainWindow", "Contact", nullptr));
        pushButton_86->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        pushButton_87->setText(QCoreApplication::translate("MainWindow", "DOWNLOAD", nullptr));
        label_98->setText(QCoreApplication::translate("MainWindow", "Email:", nullptr));
        label_100->setText(QCoreApplication::translate("MainWindow", "Payment Invoice", nullptr));
        label_101->setText(QCoreApplication::translate("MainWindow", "Name:", nullptr));
        label_102->setText(QCoreApplication::translate("MainWindow", "Paid:", nullptr));
        label_103->setText(QCoreApplication::translate("MainWindow", "Seats: ", nullptr));
        label_104->setText(QCoreApplication::translate("MainWindow", "Date & Time:", nullptr));
        label_13->setText(QString());
        label_44->setText(QString());
        lb_inv_contact->setText(QString());
        lb_inv_Email->setText(QString());
        lb_inv_Paid->setText(QString());
        lb_inv_Seats->setText(QString());
        lb_inv_Date->setText(QString());
        label_51->setText(QString());
        label_55->setText(QString());
        label_332->setText(QCoreApplication::translate("MainWindow", "From :", nullptr));
        label_333->setText(QCoreApplication::translate("MainWindow", " To :", nullptr));
        label_334->setText(QString());
        label_335->setText(QString());
        label_60->setText(QString());
        label_61->setText(QCoreApplication::translate("MainWindow", "Apply For Refund", nullptr));
        label_63->setText(QCoreApplication::translate("MainWindow", "Journey Date", nullptr));
        label_64->setText(QString());
        label_65->setText(QString());
        pushButton_43->setText(QCoreApplication::translate("MainWindow", "Submit", nullptr));
        label_66->setText(QString());
        pushButton_44->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        pushButton_45->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        label_67->setText(QCoreApplication::translate("MainWindow", "Applying Date", nullptr));
        label_68->setText(QCoreApplication::translate("MainWindow", "Refund Number", nullptr));
        lineEdit_14->setPlaceholderText(QCoreApplication::translate("MainWindow", "DD-MM-YYYY", nullptr));
        lineEdit_15->setPlaceholderText(QCoreApplication::translate("MainWindow", "DD-MM-YYYY", nullptr));
        label_41->setText(QString());
        label_70->setText(QString());
        label_71->setText(QCoreApplication::translate("MainWindow", "ADMIN", nullptr));
        pushButton_46->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        label_72->setText(QString());
        pushButton_47->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        label_74->setText(QString());
        pushButton_48->setText(QCoreApplication::translate("MainWindow", "Refund Control", nullptr));
        pushButton_49->setText(QCoreApplication::translate("MainWindow", "Seat Control", nullptr));
        label_69->setText(QString());
        pushButton_50->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        pushButton_51->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        label_75->setText(QString());
        label_76->setText(QString());
        label_77->setText(QCoreApplication::translate("MainWindow", "Seat Control", nullptr));
        label_78->setText(QCoreApplication::translate("MainWindow", "Admin ", nullptr));
        label_73->setText(QString());
        pushButton_55->setText(QCoreApplication::translate("MainWindow", "PushButton", nullptr));
        label_79->setText(QString());
        pushButton_52->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        label_80->setText(QString());
        label_81->setText(QCoreApplication::translate("MainWindow", "Admin ", nullptr));
        pushButton_53->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        label_82->setText(QCoreApplication::translate("MainWindow", "Refund Control", nullptr));
        label_83->setText(QString());
        label_84->setText(QString());
        pushButton_63->setText(QCoreApplication::translate("MainWindow", "Refundcontrol", nullptr));
        pushButton_15->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "ABOUT US", nullptr));
        label_23->setText(QString());
        pushButton_16->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        logomain_3->setText(QString());
        textBrowser->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:8pt; font-weight:700; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">Durutto is a leading online bus ticket reservation system, dedicated to simplifying your travel experience. We're committed to revolutionizing the way you book and manage your bus journeys. With a passion for innovation and a customer-centric approach, we provide a seamless platform for travelers, transport business owners, institutions, and tour ope"
                        "rators.</span></p>\n"
"<p align=\"justify\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Our<span style=\" font-size:9pt;\"> state-of-the-art technology ensures hassle-free booking and tracking, making your travel a breeze. We take pride in our user-friendly interface, extensive network coverage, and real-time information updates. Durutto is more than just a booking system; it's your trusted travel companion, offering convenience, reliability, and exceptional service.</span></p>\n"
"<p align=\"justify\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">Experience the future of bus travel with Durutto, where your journey begins with a click. Join us on our mission to redefine bus reservations and transport services.</span></p></body></html>", nullptr));
        label_24->setText(QString());
        label_52->setText(QString());
        pushButton_59->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        label_91->setText(QString());
        label_92->setText(QString());
        pushButton_60->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        label_93->setText(QString());
        label_25->setText(QCoreApplication::translate("MainWindow", "Name:", nullptr));
        label_30->setText(QCoreApplication::translate("MainWindow", "Email:", nullptr));
        label_90->setText(QCoreApplication::translate("MainWindow", "Booked Seats:", nullptr));
        label_94->setText(QCoreApplication::translate("MainWindow", "Contact:", nullptr));
        pushButton_61->setText(QCoreApplication::translate("MainWindow", "Apply For Refund", nullptr));
        label_95->setText(QString());
        label_99->setText(QCoreApplication::translate("MainWindow", "Your Dashboard", nullptr));
        pushButton_62->setText(QCoreApplication::translate("MainWindow", "Book My Ticket", nullptr));
        label_62->setText(QString());
        label_85->setText(QString());
        label_105->setText(QString());
        label_106->setText(QString());
        label_319->setText(QCoreApplication::translate("MainWindow", "Email:", nullptr));
        label_320->setText(QString());
        label_321->setText(QString());
        label_322->setText(QCoreApplication::translate("MainWindow", "Seats: ", nullptr));
        label_323->setText(QString());
        label_324->setText(QString());
        label_325->setText(QCoreApplication::translate("MainWindow", "Payment Invoice", nullptr));
        label_326->setText(QString());
        lb_inv_Date_4->setText(QString());
        logomain_13->setText(QString());
        label_327->setText(QCoreApplication::translate("MainWindow", "Date & Time:", nullptr));
        lb_inv_Email_4->setText(QString());
        lb_inv_contact_4->setText(QString());
        lb_inv_Paid_4->setText(QString());
        label_328->setText(QCoreApplication::translate("MainWindow", "Contact", nullptr));
        label_329->setText(QCoreApplication::translate("MainWindow", "Paid:", nullptr));
        lb_inv_Seats_4->setText(QString());
        label_330->setText(QCoreApplication::translate("MainWindow", "Name:", nullptr));
        label_331->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
